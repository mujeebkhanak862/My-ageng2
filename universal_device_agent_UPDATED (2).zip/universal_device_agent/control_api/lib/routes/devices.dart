import 'dart:convert';

import 'package:shelf/shelf.dart';
import 'package:shelf_router/shelf_router.dart';

import '../ai_tools/ai_tool_registry.dart';
import '../auth/device_auth.dart';
import '../models/activity.dart';
import '../models/api_key.dart';
import '../models/errors.dart';
import '../models/device.dart';
import '../storage/app_state.dart';
import '../util/crypto_utils.dart';

Router deviceRoutes(AppState state) {
  final router = Router();

  // POST /devices/pair {pairing_code, device_name}
  // Native PairingManager (Android/Windows/Linux — sab teeno mein ban
  // chuki hai) yeh code generate karta hai; yahan usko server-side
  // device record + bearer token mil jaata hai. (Pehle README mein yeh
  // "abhi sirf locally generate hota hai" note kiya gaya tha — ab yeh
  // wahi missing server-side half hai.)
  router.post('/devices/pair', (Request request) async {
    final body = jsonDecode(await request.readAsString()) as Map<String, dynamic>;
    final deviceName = body['device_name'] as String? ?? 'Unnamed Device';

    // P1-02 — platform batana ab required hai (AI Tool Registry isi se
    // device-specific capability filtering karta hai). Purane clients
    // jo yeh field bhejte hi nahi, unke liye clear error — silently
    // 'unknown' assume karna galat hota (woh permissive fallback sirf
    // *purane already-persisted* devices ke liye hai, naye pairing
    // request ke liye nahi).
    final platform = body['platform'] as String?;
    const validPlatforms = {'android', 'windows', 'linux'};
    if (platform == null || !validPlatforms.contains(platform)) {
      return ApiError.invalidRequest(
          '"platform" required hai aur in mein se ek honi chahiye: '
          '${validPlatforms.join(", ")}');
    }

    // NOTE: production mein `pairing_code` ko yahan validate karna
    // chahiye (ek short-lived server-side store mein match karke) — is
    // v1 mein hum trust-on-first-use kar rahe hain taaki end-to-end flow
    // demonstrate ho sake bina ek extra pairing-code-registry ke.
    final id = Device.generateId();
    final token = Device.generateToken();
    final now = DateTime.now().toUtc();
    state.devices[id] = Device(
      id: id,
      name: deviceName,
      bearerTokenHash: hashSecretUtil(token),
      platform: platform,
      pairedAt: now,
      lastSeenAt: now,
    );
    await state.persist();
    // Plaintext token sirf isi response mein, ek hi baar (P0-06) — server
    // ab isko kabhi dobara nahi dekhega, sirf hash store hoti hai.
    return Response.ok(
      jsonEncode({'device_id': id, 'bearer_token': token}),
      headers: {'content-type': 'application/json'},
    );
  });

  // GET /devices/{id}/status
  router.get('/devices/<id>/status', (Request request, String id) async {
    final device = state.devices[id];
    if (device == null) {
      return ApiError.notFound('Device not found');
    }
    // P1-05 — `agent_connected` `device.state` se **independent** hai:
    // `state` ek (possibly optimistic) guess ho sakti hai jab tak real
    // lock/sleep detection na aaye, lekin `agent_connected` hamesha sach
    // batata hai — WS is waqt literally connected hai ya nahi. Audit:
    // "Distinguish device online from app/agent connected."
    return Response.ok(
      jsonEncode({
        ...device.toStatusJson(),
        'agent_connected': state.deviceConnections.containsKey(id),
      }),
      headers: {'content-type': 'application/json'},
    );
  });

  // POST /devices/{id}/location — device (ya uska background agent)
  // apni location report karta hai (Section 11.5, "location.write" scope).
  router.post('/devices/<id>/location', (Request request, String id) async {
    final unauth = _requireDeviceMatching(request, id);
    if (unauth != null) return unauth;

    final device = state.devices[id];
    if (device == null) {
      return ApiError.notFound('Device not found');
    }
    final body = jsonDecode(await request.readAsString()) as Map<String, dynamic>;
    device.lastLocation = body;
    state.logActivity(ActivityEvent(
      eventType: 'location_updated',
      deviceId: id,
      timestamp: DateTime.now().toUtc(),
      status: 'success',
      actor: 'device_agent',
    ));
    await state.persist();
    return Response(204);
  });

  // GET /devices/{id}/activity?limit=N
  router.get('/devices/<id>/activity', (Request request, String id) async {
    final limitParam = request.url.queryParameters['limit'];
    final limit = int.tryParse(limitParam ?? '') ?? 50;
    final events = state.activityLog
        .where((e) => e.deviceId == id)
        .toList()
        .reversed
        .take(limit)
        .map((e) => e.toJson())
        .toList();
    return Response.ok(jsonEncode(events),
        headers: {'content-type': 'application/json'});
  });

  // GET /devices/{id}/ai-tools — P1-02: AI Tool Registry. Ek scoped API
  // key isko call karke "is device par, is key ke policy ke mutabiq,
  // abhi kaunse tools call-able hain" nikalti hai. Device-auth se nahi,
  // **API-key auth** se authenticate hota hai (audit: "active API-key/
  // policy allowed actions") — device apna khud ka token yahan use nahi
  // karta, yeh AI orchestration layer ke liye hai.
  router.get('/devices/<id>/ai-tools', (Request request, String id) async {
    final apiKey = request.context['apiKey'];
    if (apiKey == null) {
      return unauthorized('Valid scoped API key required (device bearer token nahi)');
    }
    final key = apiKey as ApiKeyRecord;

    final device = state.devices[id];
    if (device == null) {
      return ApiError.notFound('Device not found');
    }

    final tools = buildAiTools(
      device: device,
      scope: key.scope,
      customManifests: state.customCapabilityManifests,
    );

    return Response.ok(
      jsonEncode({
        'device_id': id,
        'platform': device.platform,
        'tools': tools.map((t) => t.toJson()).toList(),
      }),
      headers: {'content-type': 'application/json'},
    );
  });

  return router;
}

Response? _requireDeviceMatching(Request request, String expectedDeviceId) {
  final device = request.context['device'];
  if (device == null) {
    return unauthorized('Device auth required');
  }
  if ((device as dynamic).id != expectedDeviceId) {
    return ApiError.forbidden("Token doesn't match this device");
  }
  return null;
}
