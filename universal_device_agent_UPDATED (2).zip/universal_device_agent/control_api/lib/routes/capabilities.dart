import 'dart:convert';

import 'package:shelf/shelf.dart';
import 'package:shelf_router/shelf_router.dart';

import '../auth/device_auth.dart';
import '../models/capabilities.dart';
import '../models/custom_capability.dart';
import '../models/errors.dart';
import '../storage/app_state.dart';

/// NOTE (P0-07): `/connectors/*` routes yahan se hata kar
/// `routes/connectors.dart` mein move ho gaye hain — woh ek real OAuth
/// implementation hai, ab is file mein sirf built-in/custom capability
/// discovery hai.
Router capabilityRoutes(AppState state) {
  final router = Router();

  router.get('/capabilities', (Request request) {
    // Audit fix (follow-up to P1-02): built-in aur custom manifests ko
    // pehle bina kisi marker ke merge kiya jaata tha — koi bhi client
    // (jaise dashboard ka Permission Wizard, jo ab custom capabilities
    // explicitly grant karne ka UI deta hai) yeh distinguish nahi kar
    // sakta tha ke konsa manifest custom hai (jise per-key grant karna
    // hai) aur konsa built-in (jiske apne fixed scope toggles already
    // hain). `is_custom` field add kiya — purane consumers ke liye
    // backward-compatible (naya field, kuch hataya nahi).
    final all = [
      ...builtInCapabilityManifests().map((m) => {...m, 'is_custom': false}),
      ...state.customCapabilityManifests.map((m) => {...m, 'is_custom': true}),
    ];
    return Response.ok(jsonEncode(all),
        headers: {'content-type': 'application/json'});
  });

  router.get('/capabilities/<name>/schema', (Request request, String name) {
    final all = [...builtInCapabilityManifests(), ...state.customCapabilityManifests];
    final match = all.where((m) => m['capability'] == name);
    if (match.isEmpty) {
      return ApiError.notFound('Unknown capability');
    }
    return Response.ok(jsonEncode(match.first),
        headers: {'content-type': 'application/json'});
  });

  // POST /capabilities/register — P1-01: ab persistent + validated +
  // trust-aware hai. Pehle: koi auth check nahi thi, koi shape
  // validation nahi thi, aur restart par sab gayab ho jaata tha.
  router.post('/capabilities/register', (Request request) async {
    // ---- Trust boundary #1: registration ke liye device-authentication
    // zaroori hai — pehle bilkul koi bhi unauthenticated request register
    // kar sakti thi (audit: "Untrusted client ko privileged capability
    // register na karne dein" — sabse pehla, sabse zaroori qadam yeh hai
    // ke koi bhi anonymous client kuch bhi register hi na kar sake).
    final device = request.context['device'];
    if (device == null) {
      return unauthorized('Capability registration ke liye device auth required hai');
    }

    Map<String, dynamic> body;
    try {
      final parsed = jsonDecode(await request.readAsString());
      if (parsed is! Map<String, dynamic>) {
        return ApiError.invalidRequest('Request body ek JSON object hona chahiye');
      }
      body = parsed;
    } on FormatException catch (e) {
      return ApiError.invalidRequest('Malformed JSON: ${e.message}');
    }

    // ---- Shape/schema validation --------------------------------------
    final builtInNames = builtInCapabilityManifests().map((m) => m['capability'] as String).toSet();
    final alreadyRegisteredNames =
        state.customCapabilityManifests.map((m) => m['capability'] as String).toSet();
    final reservedNames = {...builtInNames, ...alreadyRegisteredNames};

    final validation = validateCustomManifest(body, reservedNames);
    if (!validation.isValid) {
      return ApiError.invalidRequest(validation.error!);
    }

    // ---- Trust boundary #2: privileged (high-risk) capabilities ---------
    // Is system mein filhaal koi "trusted operator"/admin tier nahi hai
    // (sirf paired device aur scoped API keys) — is liye conservative
    // default: koi bhi high-risk custom capability register hi nahi ho
    // sakti, chahe request device-authenticated hi kyun na ho.
    if (manifestIsPrivileged(body)) {
      return ApiError.forbidden(
          'Is manifest mein kam-se-kam ek "high" risk_level action hai — '
          'privileged capabilities is server se register nahi ho saktin');
    }

    state.customCapabilityManifests.add(body);
    await state.persist();

    return Response.ok(jsonEncode(body), headers: {'content-type': 'application/json'});
  });

  return router;
}
