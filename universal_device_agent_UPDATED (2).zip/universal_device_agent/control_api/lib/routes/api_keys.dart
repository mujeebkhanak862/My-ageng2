import 'dart:convert';
import 'dart:math';

import 'package:shelf/shelf.dart';
import 'package:shelf_router/shelf_router.dart';

import '../auth/device_auth.dart';
import '../models/api_key.dart';
import '../models/errors.dart';
import '../storage/app_state.dart';

Router apiKeyRoutes(AppState state) {
  final router = Router();

  // POST /api-keys {label, scope} — device-authenticated (dashboard app
  // khud apne device ke liye key bana raha hai, Section 3.2 Key Generator).
  router.post('/api-keys', (Request request) async {
    final device = request.context['device'];
    if (device == null) return unauthorized('Device auth required');

    final body = jsonDecode(await request.readAsString()) as Map<String, dynamic>;
    final label = body['label'] as String? ?? '';
    final scope = ApiKeyScope.fromJson(
        (body['scope'] as Map<String, dynamic>?) ?? const {});

    final keyId = 'key_${_randomHex(8)}';
    final secret = ApiKeyRecord.generateSecret();
    final record = ApiKeyRecord(
      keyId: keyId,
      deviceId: (device as dynamic).id as String,
      label: label,
      scope: scope,
      createdAt: DateTime.now().toUtc(),
      secretHash: ApiKeyRecord.hashSecret(secret),
    );
    state.apiKeys[keyId] = record;
    await state.persist();

    // Secret sirf isi response mein ek baar dikhta hai — Dart dashboard
    // (key_manager_screen.dart) ka "Secret sirf ek baar dikhega" dialog
    // isi wajah se hai.
    return Response.ok(
      jsonEncode(record.toJson(plaintextSecretOnce: secret)),
      headers: {'content-type': 'application/json'},
    );
  });

  // GET /api-keys — sirf calling device ki apni keys.
  router.get('/api-keys', (Request request) async {
    final device = request.context['device'];
    if (device == null) return unauthorized('Device auth required');
    final deviceId = (device as dynamic).id as String;

    final keys = state.apiKeys.values
        .where((k) => k.deviceId == deviceId)
        .map((k) => k.toJson())
        .toList();
    return Response.ok(jsonEncode(keys),
        headers: {'content-type': 'application/json'});
  });

  // PATCH /api-keys/{id}/permissions {scope}
  router.patch('/api-keys/<id>/permissions', (Request request, String id) async {
    final device = request.context['device'];
    if (device == null) return unauthorized('Device auth required');

    final record = state.apiKeys[id];
    if (record == null || record.deviceId != (device as dynamic).id) {
      return ApiError.notFound('Key not found');
    }
    final body = jsonDecode(await request.readAsString()) as Map<String, dynamic>;
    final newScope = ApiKeyScope.fromJson(
        (body['scope'] as Map<String, dynamic>?) ?? const {});
    final updated = ApiKeyRecord(
      keyId: record.keyId,
      deviceId: record.deviceId,
      label: record.label,
      scope: newScope,
      createdAt: record.createdAt,
      secretHash: record.secretHash,
      enabled: record.enabled,
    );
    state.apiKeys[id] = updated;
    await state.persist();
    return Response.ok(jsonEncode(updated.toJson()),
        headers: {'content-type': 'application/json'});
  });

  // PATCH /api-keys/{id}/status {enabled: bool} — **disable/re-enable**
  // (audit P0-02: "Key revoke/disable must invalidate future requests
  // immediately"). DELETE (neeche) permanent revoke ke liye hai; yeh
  // endpoint temporary "pause this key" ke liye — jaise DELETE, effect
  // turant hai kyunki auth middleware har request par live
  // `state.apiKeys` map check karta hai, koi caching nahi.
  router.patch('/api-keys/<id>/status', (Request request, String id) async {
    final device = request.context['device'];
    if (device == null) return unauthorized('Device auth required');

    final record = state.apiKeys[id];
    if (record == null || record.deviceId != (device as dynamic).id) {
      return ApiError.notFound('Key not found');
    }
    final body = jsonDecode(await request.readAsString()) as Map<String, dynamic>;
    final enabled = body['enabled'] as bool?;
    if (enabled == null) {
      return ApiError.invalidRequest('"enabled" (bool) field required');
    }
    record.enabled = enabled;
    await state.persist();
    return Response.ok(jsonEncode(record.toJson()),
        headers: {'content-type': 'application/json'});
  });

  // DELETE /api-keys/{id} — turant revoke.
  router.delete('/api-keys/<id>', (Request request, String id) async {
    final device = request.context['device'];
    if (device == null) return unauthorized('Device auth required');

    final record = state.apiKeys[id];
    if (record == null || record.deviceId != (device as dynamic).id) {
      return ApiError.notFound('Key not found');
    }
    state.apiKeys.remove(id);
    await state.persist();
    return Response(204);
  });

  return router;
}

String _randomHex(int length) {
  final rand = Random.secure();
  return List.generate(length, (_) => rand.nextInt(16).toRadixString(16))
      .join();
}
