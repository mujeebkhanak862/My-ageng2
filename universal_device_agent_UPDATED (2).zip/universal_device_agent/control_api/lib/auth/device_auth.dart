import 'package:shelf/shelf.dart';

import '../models/api_key.dart';
import '../models/errors.dart';
import '../storage/app_state.dart';

/// `Authorization: Bearer <token>` do cheezein ho sakta hai:
///  - Device ka apna bearer token (pairing se mila) — device khud apni
///    keys manage kar raha hai (dashboard app se).
///  - Ek scoped API key ka secret — koi external client (AI agent) is
///    device ko control kar raha hai.
///
/// Middleware dono try karta hai aur jo bhi match kare, request context
/// mein daal deta hai (`context['device']` ya `context['apiKey']`).
/// Route handlers khud decide karte hain unhe kaunsa chahiye tha.
Middleware deviceAuthMiddleware(AppState state) {
  return (Handler innerHandler) {
    return (Request request) async {
      final authHeader = request.headers['authorization'];
      if (authHeader == null || !authHeader.startsWith('Bearer ')) {
        return innerHandler(request);
      }
      final token = authHeader.substring('Bearer '.length);

      final device = state.deviceByToken(token);
      if (device != null) {
        return innerHandler(request.change(context: {'device': device}));
      }

      final hash = ApiKeyRecord.hashSecret(token);
      for (final key in state.apiKeys.values) {
        if (key.secretHash == hash && key.enabled) {
          return innerHandler(request.change(context: {'apiKey': key}));
        }
      }

      return innerHandler(request);
    };
  };
}

/// PROTOCOL_V1.md canonical error envelope se — pehle yahan ek alag
/// ad-hoc `{"error": message}` shape thi, ab sab routes isi ek function
/// se guzarte hain.
Response unauthorized(String message) => ApiError.unauthorized(message);
