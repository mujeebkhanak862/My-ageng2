/// P1-08 — Data Channel Hardening — Upload/Download/File Security.
///
/// Audit: "Native Android/Linux/Windows path traversal protection
/// exists" (device-side, real filesystem-root enforcement — sirf woh
/// device apne actual filesystem ke against kar sakta hai) — "lekin
/// server-side scoped authorization, file-size limits, MIME/type
/// validation... remain." Yeh file wahi **server-side, defense-in-depth**
/// layer hai — device tak koi obviously malicious path/oversized/
/// dangerous-type payload kabhi forward hi nahi hone dete.
///
/// **Scope boundary (honest)**: server ke paas device ka real filesystem
/// nahi hai, is liye yeh sirf **pattern-level** checks kar sakta hai
/// (traversal sequences, extension allowlist/blocklist, size) — asal
/// "allowed root" enforcement (jaise "sirf /sdcard/Download ke andar")
/// device-side hi ho sakta hai (jo audit ke mutabiq already maujood
/// hai). Yeh dono layers saath mein defense-in-depth banate hain.
library;

import 'dart:convert';

class PathValidationResult {
  final bool isValid;
  final String? error;
  const PathValidationResult._(this.isValid, this.error);
  factory PathValidationResult.valid() => const PathValidationResult._(true, null);
  factory PathValidationResult.invalid(String error) => PathValidationResult._(false, error);
}

/// DATA-01 acceptance: "traversal rejected". `..` kisi bhi form mein
/// (`../`, `..\`, URL-encoded `%2e%2e` already P0-04 ke JSON string
/// decode ke baad plain `..` ban chuki hoti hai) — substring check hi
/// kaafi hai, encoding tricks JSON parse ke baad automatically resolve
/// ho chuki hoti hain.
PathValidationResult validateFilePath(String path) {
  if (path.isEmpty) {
    return PathValidationResult.invalid('Path khaali nahi ho sakta');
  }
  if (path.contains('..')) {
    return PathValidationResult.invalid(
        'Path mein ".." (parent-directory traversal) allowed nahi hai');
  }
  if (path.contains('\u0000')) {
    return PathValidationResult.invalid('Path mein null byte allowed nahi hai');
  }
  if (path.length > 4096) {
    return PathValidationResult.invalid('Path 4096 characters se zyada lamba hai');
  }
  return PathValidationResult.valid();
}

/// `files.write`/`data.upload` ke liye alag, zyada generous size limit —
/// `validation/schema_validator.dart`'s general `maxRequestBodyBytes`
/// (2 MiB, saari commands ke liye) is se chhota hai, file transfers ke
/// liye woh limit bohot tight hai. Yeh limit specifically inhi
/// payload-carrying actions par lagta hai.
const maxUploadPayloadBytes = 10 * 1024 * 1024; // 10 MiB

/// `payload` field base64 string hai — decode kiye bina hi uski
/// approximate decoded size nikal lete hain (base64 ~4/3x overhead —
/// exact decode se pehle hi reject karna sasta hai, especially bade
/// malicious payloads ke liye).
class PayloadSizeResult {
  final bool isValid;
  final String? error;
  final int? decodedByteLength;
  const PayloadSizeResult._(this.isValid, this.error, this.decodedByteLength);
  factory PayloadSizeResult.valid(int decodedByteLength) =>
      PayloadSizeResult._(true, null, decodedByteLength);
  factory PayloadSizeResult.invalid(String error) => PayloadSizeResult._(false, error, null);
}

PayloadSizeResult validateUploadPayloadSize(String? base64Payload) {
  if (base64Payload == null || base64Payload.isEmpty) {
    return PayloadSizeResult.invalid(
        'Is action ke liye "payload" (base64 file content) required hai');
  }
  // Base64 decoded size ≈ base64Length * 3/4 (padding ignore karte hue,
  // yeh estimate hamesha thoda upar hi hota hai, jo safe direction hai).
  final estimatedBytes = (base64Payload.length * 3) ~/ 4;
  if (estimatedBytes > maxUploadPayloadBytes) {
    return PayloadSizeResult.invalid(
        'Payload $maxUploadPayloadBytes bytes (~${maxUploadPayloadBytes ~/ (1024 * 1024)} MiB) '
        'se zyada hai — SEC-02: oversized upload dispatch se pehle hi reject');
  }
  // Estimate ke baad bhi actual decode zaroori hai — malformed base64
  // bhi yahin pakad lete hain (device tak corrupt payload forward nahi
  // hoti).
  try {
    final bytes = base64.decode(base64Payload);
    if (bytes.length > maxUploadPayloadBytes) {
      return PayloadSizeResult.invalid(
          'Payload $maxUploadPayloadBytes bytes se zyada hai (decoded: ${bytes.length})');
    }
    return PayloadSizeResult.valid(bytes.length);
  } on FormatException {
    return PayloadSizeResult.invalid('"payload" valid base64 nahi hai');
  }
}

/// Blocklist (allowlist nahi — yeh tool jaan-bujh kar general-purpose
/// hai, users apni arbitrary files transfer karna chahte hain, is liye
/// ek strict allowlist bohot restrictive hoti). Sirf genuinely
/// dangerous-to-execute types block karte hain — self-propagating
/// malware/executable payloads ka sabse aam vector.
const _dangerousExtensions = {
  '.exe', '.msi', '.bat', '.cmd', '.com', '.scr', // Windows executables
  '.sh', '.bash', '.run', // Unix/Linux scripts
  '.apk', // Android installer — user apne aap install kar sakta hai UI se, lekin silent-write high-risk hai
  '.dll', '.so', '.dylib', // native libraries
  '.jar', // Java executable
};

/// MIME/type check — extension-based (path se) hai, content-sniffing
/// nahi (decode kiye bina hi reject karna sasta hai). `files.write` aur
/// `data.upload` dono is se guzarte hain.
PathValidationResult validateUploadFileType(String path) {
  final lower = path.toLowerCase();
  for (final ext in _dangerousExtensions) {
    if (lower.endsWith(ext)) {
      return PathValidationResult.invalid(
          'File type "$ext" security reasons se upload allowed nahi hai '
          '(executable/installer types blocked)');
    }
  }
  return PathValidationResult.valid();
}
