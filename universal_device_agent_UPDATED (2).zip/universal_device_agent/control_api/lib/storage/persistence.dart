import 'dart:convert';
import 'dart:io';

import '../models/activity.dart';
import '../models/api_key.dart';
import '../models/device.dart';
import '../models/task.dart';
import '../connectors/connector_models.dart';
import '../util/crypto_utils.dart';
import 'app_state.dart';

/// Simple JSON-file persistence — **jaan-bujh kar SQLite/Postgres nahi
/// use kiya** kyunki:
///  1. Is project ke scale ke liye (ek user ke devices) yeh kaafi hai.
///  2. Koi native dependency (sqlite3 native lib) nahi chahiye — Docker
///     build simple aur reliable rehta hai.
///  3. Is sandbox mein Dart SDK khud available nahi thi (README mein
///     already note hai), isliye jitna simple rakh sakoon utna behtar —
///     kam moving parts, kam jagah bug chhup sakti hai.
///
/// **Railway par persistence ke liye Volume attach karna zaroori hai**
/// (neeche `dataDirectory()` ka comment dekho) — warna yeh file bhi
/// container restart par delete ho jaayegi, jaisa in-memory data hota.
class Persistence {
  final AppState state;
  final File _file;

  /// `fileOverride` — sirf tests ke liye (temp file inject karne ke
  /// liye, taaki `DATA_DIR` env var chhede bina persistence ka poora
  /// save/load round-trip test ho sake). Normal use mein hamesha
  /// `dataDirectory()`/`DATA_DIR` se hi path aata hai.
  Persistence(this.state, {File? fileOverride})
      : _file = fileOverride ?? File('${dataDirectory()}/state.json');

  /// `DATA_DIR` environment variable se path leta hai (default `/data`).
  /// **Railway setup:** apne service mein ek Volume attach karo, mount
  /// path `/data` do — us Volume ka content hi restarts ke beech survive
  /// karta hai. Volume attach kiye bina, `/data` container ke andar hi
  /// ek normal (ephemeral) folder hoga aur restart par sab kuch phir se
  /// khatam ho jaayega — matlab yeh code sahi hai, lekin Railway
  /// dashboard mein Volume attach karna ek zaroori extra step hai.
  static String dataDirectory() =>
      Platform.environment['DATA_DIR'] ?? '/data';

  Future<void> load() async {
    try {
      if (!await _file.exists()) return;
      final raw = await _file.readAsString();
      final json = jsonDecode(raw) as Map<String, dynamic>;

      for (final d in (json['devices'] as List<dynamic>? ?? [])) {
        final m = d as Map<String, dynamic>;
        state.devices[m['id']] = Device(
          id: m['id'] as String,
          name: m['name'] as String,
          // P0-06 migration: purane persisted files mein plaintext
          // `bearer_token` hota tha, naye mein sirf `bearer_token_hash`.
          // Dono handle karte hain — agar sirf legacy plaintext mila, to
          // usi waqt hash kar lete hain (agli `save()` call se file khud
          // naye format mein migrate ho jayegi). Isse ek existing Railway
          // deployment ka data crash/wipe nahi hota upgrade ke baad.
          bearerTokenHash: (m['bearer_token_hash'] as String?) ??
              hashSecretUtil(m['bearer_token'] as String),
          // P1-02 migration: purane persisted devices ke paas yeh field
          // nahi hogi — 'unknown' fallback (AI Tool Registry isko
          // "platform filter skip karo" ki tarah treat karta hai).
          platform: m['platform'] as String? ?? 'unknown',
          pairedAt: DateTime.parse(m['paired_at'] as String),
          lastSeenAt: DateTime.parse(m['last_seen_at'] as String),
          state: m['state'] as String? ?? 'OFFLINE',
          backgroundActive: m['background_active'] as bool? ?? false,
          batteryPercent: m['battery_percent'] as int?,
          lastLocation: m['last_location'] as Map<String, dynamic>?,
          lastNetwork: m['last_network'] as Map<String, dynamic>?,
        );
      }

      for (final k in (json['api_keys'] as List<dynamic>? ?? [])) {
        final m = k as Map<String, dynamic>;
        state.apiKeys[m['key_id']] = ApiKeyRecord(
          keyId: m['key_id'] as String,
          deviceId: m['device_id'] as String,
          label: m['label'] as String,
          scope: ApiKeyScope.fromJson(m['scope'] as Map<String, dynamic>),
          createdAt: DateTime.parse(m['created_at'] as String),
          secretHash: m['secret_hash'] as String,
          enabled: m['enabled'] as bool? ?? true,
        );
      }

      for (final e in (json['activity_log'] as List<dynamic>? ?? [])) {
        final m = e as Map<String, dynamic>;
        state.activityLog.add(ActivityEvent(
          eventType: m['event_type'] as String,
          deviceId: m['device_id'] as String,
          source: m['source'] as String?,
          taskId: m['task_id'] as String?,
          timestamp: DateTime.parse(m['timestamp'] as String),
          status: m['status'] as String,
          actor: m['actor'] as String,
          category: m['category'] as String?,
        ));
      }

      // P0-07 — connector credentials. Field values yahan sirf
      // **encrypted** strings hain (`encrypted_access_token`/
      // `encrypted_refresh_token`) — disk par kabhi plaintext token
      // nahi jaati.
      for (final c in (json['connector_credentials'] as List<dynamic>? ?? [])) {
        final m = c as Map<String, dynamic>;
        state.storeConnectorCredential(ConnectorCredential(
          deviceId: m['device_id'] as String,
          connectorName: m['connector_name'] as String,
          encryptedAccessToken: m['encrypted_access_token'] as String,
          encryptedRefreshToken: m['encrypted_refresh_token'] as String?,
          accessTokenExpiresAt: DateTime.parse(m['access_token_expires_at'] as String),
          grantedScopes: (m['granted_scopes'] as List<dynamic>? ?? []).cast<String>(),
          connectedAt: DateTime.parse(m['connected_at'] as String),
        ));
      }

      // P1-01 — persistent custom capability manifests. Yeh already
      // validated (registration ke waqt) JSON-shaped data hain, as-is
      // store/load karte hain.
      for (final m in (json['custom_capability_manifests'] as List<dynamic>? ?? [])) {
        state.customCapabilityManifests.add(m as Map<String, dynamic>);
      }

      // Audit fix (Section 8 / Section 13 #2) — pehle `state.tasks`
      // bilkul persist hi nahi hota tha: server restart hote hi saari
      // TaskRecord state (RUNNING/PAUSED/..., aur khaaskar
      // `lastCheckpoint`) memory se gayab ho jaati — matlab "resume =>
      // checkpoint se continue" restart ke baad kabhi kaam hi nahi kar
      // sakta tha, chahe checkpoint reporting kitni bhi sahi ho. Ab
      // baaki state ki tarah yeh bhi load/save hota hai.
      for (final t in (json['tasks'] as List<dynamic>? ?? [])) {
        final m = t as Map<String, dynamic>;
        final taskId = m['task_id'] as String;
        state.tasks[taskId] = TaskRecord(
          taskId: taskId,
          deviceId: m['device_id'] as String,
          originatingCapability: m['capability'] as String,
          state: taskStateFromWire(m['state'] as String?) ?? TaskState.stopped,
          createdAt: DateTime.parse(m['created_at'] as String),
          updatedAt: DateTime.parse(m['updated_at'] as String),
          lastCheckpoint: m['checkpoint'] as Map<String, dynamic>?,
        )..terminalReason = m['reason'] as String?;
      }

      // ignore: avoid_print
      print('Persistence: loaded ${state.devices.length} devices, '
          '${state.apiKeys.length} keys, ${state.activityLog.length} '
          'activity events, ${state.connectorCredentials.length} connector '
          'credentials, ${state.customCapabilityManifests.length} custom '
          'capability manifests, ${state.tasks.length} tasks from ${_file.path}');
    } catch (e) {
      // Corrupt ya missing file — khaali state se shuru karo, crash mat
      // karo. Behtar hai ek device dobara pair kare, server crash ho
      // jaaye se.
      // ignore: avoid_print
      print('Persistence: load failed ($e), starting fresh');
    }
  }

  /// Har mutation ke baad call hota hai (routes mein already wired).
  /// Poora state ek JSON file mein overwrite karta hai — is scale
  /// (chhoti si device list) ke liye yeh kaafi fast hai, koi incremental
  /// diffing ki zaroorat nahi.
  Future<void> save() async {
    try {
      await _file.parent.create(recursive: true);

      final json = {
        'devices': state.devices.values
            .map((d) => {
                  'id': d.id,
                  'name': d.name,
                  'bearer_token_hash': d.bearerTokenHash,
                  'platform': d.platform,
                  'paired_at': d.pairedAt.toIso8601String(),
                  'last_seen_at': d.lastSeenAt.toIso8601String(),
                  'state': d.state,
                  'background_active': d.backgroundActive,
                  'battery_percent': d.batteryPercent,
                  'last_location': d.lastLocation,
                  'last_network': d.lastNetwork,
                })
            .toList(),
        'api_keys': state.apiKeys.values
            .map((k) => {
                  'key_id': k.keyId,
                  'device_id': k.deviceId,
                  'label': k.label,
                  'scope': k.scope.toJson(),
                  'created_at': k.createdAt.toIso8601String(),
                  'secret_hash': k.secretHash,
                  'enabled': k.enabled,
                })
            .toList(),
        // Activity log — sirf last 2000 events persist karte hain (poora
        // in-memory bound already 5000 hai, disk par thoda tighter rakha
        // taaki file zyada bada na ho).
        'activity_log': state.activityLog
            .skip(state.activityLog.length > 2000 ? state.activityLog.length - 2000 : 0)
            .map((e) => e.toJson())
            .toList(),
        // P0-07 — connector credentials, **encrypted values hi** (kabhi
        // plaintext nahi) — `credential_encryption.dart` se already
        // encrypted aati hain, yahan sirf as-is serialize ho rahi hain.
        'connector_credentials': state.connectorCredentials.values
            .map((c) => {
                  'device_id': c.deviceId,
                  'connector_name': c.connectorName,
                  'encrypted_access_token': c.encryptedAccessToken,
                  'encrypted_refresh_token': c.encryptedRefreshToken,
                  'access_token_expires_at': c.accessTokenExpiresAt.toIso8601String(),
                  'granted_scopes': c.grantedScopes,
                  'connected_at': c.connectedAt.toIso8601String(),
                })
            .toList(),
        // P1-01 — custom capability manifests.
        'custom_capability_manifests': state.customCapabilityManifests,
        // Audit fix (Section 8 / Section 13 #2) — task lifecycle state
        // (including lastCheckpoint) ab persist hoti hai (dekhein load()
        // ka comment).
        'tasks': state.tasks.values.map((t) => t.toJson()).toList(),
      };

      // Atomic write — pehle temp file, phir rename. Isse agar save ke
      // beech mein process crash ho jaaye, purani file corrupt nahi
      // hoti (naya write ya poora hota hai ya bilkul nahi).
      final tempFile = File('${_file.path}.tmp');
      await tempFile.writeAsString(jsonEncode(json));

      // DEP-01 — safe file permissions: owner-only read/write (0600).
      // File mein encrypted connector tokens aur hashes hain (kabhi
      // plaintext secret nahi — P0-06/P0-07), lekin defense-in-depth
      // ke tor par bhi is file ko world-readable chhodna koi wajah nahi
      // hai. POSIX-only (`chmod` Windows par kuch aur maayne rakhta
      // hai — Windows par yeh silently ignore ho jaata hai, koi crash
      // nahi).
      if (!Platform.isWindows) {
        try {
          await Process.run('chmod', ['600', tempFile.path]);
        } catch (_) {
          // chmod na chal paaye (kuch minimal containers mein nahi
          // hota) — save khud fail nahi honi chahiye is wajah se.
        }
      }

      await tempFile.rename(_file.path);
    } catch (e) {
      // Save fail hona should crash na kare request handling — sirf log.
      // ignore: avoid_print
      print('Persistence: save failed: $e');
    }
  }

  /// DEP-01 — startup health check: DATA_DIR mein likh sakte hain ya
  /// nahi, yeh turant pata chal jaana chahiye (server start hote hi),
  /// na ke pehle real save() call fail hone par kisi request ke beech
  /// mein. Read-only filesystem, missing permissions, waghera turant
  /// pakde jaate hain.
  ///
  /// Return `true` = likh sakte hain. `false` = nahi likh sakte — caller
  /// (`bin/server.dart`) is case mein ek loud, unmissable warning print
  /// karta hai (server phir bhi start hota hai — read-only mode mein
  /// chalna, crash hone se behtar hai — lekin operator ko turant pata
  /// chal jaana chahiye).
  Future<bool> verifyWritable() async {
    try {
      await _file.parent.create(recursive: true);
      final probe = File('${_file.parent.path}/.write_probe');
      await probe.writeAsString(DateTime.now().toIso8601String());
      await probe.delete();
      return true;
    } catch (_) {
      return false;
    }
  }
}
