package com.deviceagent.app

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.util.Base64
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel

/**
 * Native side of `ChannelNames.screenCapture` (MethodChannel) and
 * `ChannelNames.screenLiveStream` (EventChannel) from
 * platform_channel_bridge.dart — matches `ScreenCaptureBridge` in Dart.
 *
 * Flow:
 *  1. Dart calls "requestPermission" → MainActivity shows the mandatory
 *     Android system consent dialog (cannot be bypassed — Section 6.6
 *     item 2).
 *  2. On approval, MainActivity starts ScreenCaptureService with the
 *     granted resultCode/Intent.
 *  3. "captureScreenshot" → one-shot PNG, base64-encoded.
 *  4. EventChannel onListen → continuous JPEG frames for "Watch Live"
 *     (Section 2.1).
 */
class ScreenCaptureHandler(private val activity: MainActivity) {

    private var pendingPermissionResult: MethodChannel.Result? = null

    fun register(flutterEngine: FlutterEngine) {
        val methodChannel = MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            ChannelNames.screenCapture
        )
        methodChannel.setMethodCallHandler { call, result ->
            when (call.method) {
                "requestPermission" -> requestPermission(result)
                "captureScreenshot" -> captureScreenshot(result)
                "stopStream" -> {
                    activity.currentScreenCaptureService()?.stopStreaming()
                    result.success(null)
                }
                else -> result.notImplemented()
            }
        }

        val eventChannel = EventChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            ChannelNames.screenLiveStream
        )
        eventChannel.setStreamHandler(object : EventChannel.StreamHandler {
            override fun onListen(arguments: Any?, events: EventChannel.EventSink) {
                activity.currentScreenCaptureService()?.startStreaming { frameBytes ->
                    activity.runOnUiThread {
                        events.success(Base64.encodeToString(frameBytes, Base64.NO_WRAP))
                    }
                }
            }

            override fun onCancel(arguments: Any?) {
                // Section 2.5 — turant band, koi background leak nahi.
                activity.currentScreenCaptureService()?.stopStreaming()
            }
        })
    }

    private fun requestPermission(result: MethodChannel.Result) {
        pendingPermissionResult = result
        val manager = activity.getSystemService(
            android.content.Context.MEDIA_PROJECTION_SERVICE
        ) as MediaProjectionManager
        activity.startActivityForResult(
            manager.createScreenCaptureIntent(),
            MainActivity.REQUEST_CODE_SCREEN_CAPTURE
        )
    }

    /** MainActivity.onActivityResult isko call karta hai jab consent mil jaaye. */
    fun onPermissionResult(resultCode: Int, data: Intent?) {
        val granted = resultCode == Activity.RESULT_OK && data != null
        pendingPermissionResult?.success(granted)
        pendingPermissionResult = null

        if (granted) {
            val serviceIntent = Intent(activity, ScreenCaptureService::class.java).apply {
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
            }
            activity.startForegroundService(serviceIntent)
        }
    }

    private fun captureScreenshot(result: MethodChannel.Result) {
        val png = activity.currentScreenCaptureService()?.captureLatestFrameAsPng()
        if (png == null) {
            result.error("NOT_READY", "Screen capture session active nahi hai", null)
        } else {
            result.success(Base64.encodeToString(png, Base64.NO_WRAP))
        }
    }
}
