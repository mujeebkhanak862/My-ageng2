package com.deviceagent.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import androidx.core.app.NotificationCompat
import java.io.ByteArrayOutputStream
import android.graphics.Bitmap
import android.graphics.PixelFormat

/**
 * Foreground Service jahan MediaProjection session actually chalti hai
 * (Section 6.6 item 1 & Section 6.7 file list). Android 14+ ke liye
 * foregroundServiceType="mediaProjection" AndroidManifest.xml mein already
 * declared hai.
 *
 * Consent (system dialog) yahan se nahi maanga jaata — woh Activity-level
 * kaam hai (MainActivity), is service ko sirf approved
 * `Intent`/`resultCode` milta hai aur woh session start kar deti hai.
 */
class ScreenCaptureService : Service() {

    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val NOTIFICATION_CHANNEL_ID = "screen_capture_channel"
        private const val NOTIFICATION_ID = 1001

        // Latest captured frame yahan expose hoti hai taaki
        // ScreenCaptureHandler (MethodChannel/EventChannel) ise consume kar sake.
        var onFrameCaptured: ((ByteArray) -> Unit)? = null

        // Service normally-bound nahi hai (sirf foreground + intent-started),
        // isliye handler ko current running instance yahan se milta hai.
        var instance: ScreenCaptureService? = null
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var streaming = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification())

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, -1) ?: -1
        val resultData: Intent? = intent?.getParcelableExtra(EXTRA_RESULT_DATA)

        if (resultCode != -1 && resultData != null) {
            val manager =
                getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mediaProjection = manager.getMediaProjection(resultCode, resultData)
            setUpVirtualDisplay()
        }

        return START_NOT_STICKY
    }

    private fun setUpVirtualDisplay() {
        val metrics = DisplayMetrics()
        val windowManager = getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)

        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "DeviceAgentScreenCapture",
            width, height, density,
            android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, null
        )
    }

    /** One-shot capture — `screen.capture` command. */
    fun captureLatestFrameAsPng(): ByteArray? {
        val reader = imageReader ?: return null
        val image = reader.acquireLatestImage() ?: return null
        try {
            val bitmap = imageToBitmap(image)
            try {
                val out = ByteArrayOutputStream()
                bitmap.compress(Bitmap.CompressFormat.PNG, 90, out)
                return out.toByteArray()
            } finally {
                bitmap.recycle()
            }
        } finally {
            image.close()
        }
    }

    /**
     * `Image` (ImageReader se) ko crop-adjusted `Bitmap` mein convert karta
     * hai. **Real bug jo yahan pehle tha (dono `captureLatestFrameAsPng()`
     * aur `startStreaming()` mein duplicate tha)**: `ImageReader`'s row
     * stride GPU buffer alignment ki wajah se aksar image ki asal width se
     * zyada hoti hai (jaise 1080px width ko 1088px tak pad kiya jaana aam
     * baat hai) — is extra `rowPadding` ko account karne ke liye bitmap
     * **wider** banaya jaata tha (`image.width + rowPadding/pixelStride`),
     * lekin phir use kabhi wapas asal `image.width` tak **crop nahi kiya
     * jaata tha** — result: har screenshot/live-frame mein right edge par
     * garbage/skewed pixels aate (bilkul stretched/corrupted dikhta), sirf
     * un devices par jahan `rowPadding > 0` ho (zyada-tar real devices).
     * Ab: extra-wide bitmap banane ke baad explicitly crop karte hain.
     */
    private fun imageToBitmap(image: android.media.Image): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width

        val paddedBitmap = Bitmap.createBitmap(
            image.width + rowPadding / pixelStride, image.height, Bitmap.Config.ARGB_8888
        )
        paddedBitmap.copyPixelsFromBuffer(buffer)

        if (rowPadding == 0) return paddedBitmap // koi crop zaroori nahi, fast path

        val cropped = Bitmap.createBitmap(paddedBitmap, 0, 0, image.width, image.height)
        paddedBitmap.recycle() // memory leak se bachne ke liye — yeh per-frame chalta hai
        return cropped
    }

    /** Continuous stream shuru karta hai — `screen.watch_live` command. */
    fun startStreaming(onFrame: (ByteArray) -> Unit) {
        streaming = true
        imageReader?.setOnImageAvailableListener({ reader ->
            if (!streaming) return@setOnImageAvailableListener
            val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val bitmap = imageToBitmap(image)
                try {
                    val out = ByteArrayOutputStream()
                    // Live stream ke liye JPEG — Section 2.1 "adaptive FPS,
                    // low bandwidth" requirement, PNG se lighter.
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 60, out)
                    onFrame(out.toByteArray())
                } finally {
                    bitmap.recycle()
                }
            } finally {
                image.close()
            }
        }, null)
    }

    /** Section 2.5 — task complete/paused hote hi stream band, koi leak nahi. */
    fun stopStreaming() {
        streaming = false
        imageReader?.setOnImageAvailableListener(null, null)
    }

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                "Screen sharing",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
        // Section 2.5 — user ko hamesha pata hona chahiye jab screen shared
        // ho rahi ho; yeh persistent notification isi requirement ko poora
        // karti hai (OS bhi ise MediaProjection ke liye mandatory karta hai).
        return NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setContentTitle("Device Agent")
            .setContentText("Screen is being shared")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        stopStreaming()
        virtualDisplay?.release()
        mediaProjection?.stop()
        instance = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
