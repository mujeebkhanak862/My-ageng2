package com.deviceagent.app

import android.Manifest
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Bundle
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Native side of `ChannelNames.locationNetwork` — matches Dart's
 * `LocationNetworkBridge`. Returns maps with exactly the field names
 * `DeviceLocation.fromJson`/`DeviceNetwork.fromJson` (Section 11) expect
 * — `latitude`/`longitude`/`accuracy_m`/`timestamp`/`source` and
 * `connected`/`ssid`/`connection_type`/`timestamp` — taaki yeh data
 * seedha `api_client.dart`'s `reportLocation()` ko forward kiya ja sake.
 */
class LocationNetworkHandler(private val activity: MainActivity) {

    private var pendingPermissionResult: MethodChannel.Result? = null
    private val isoFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }

    fun register(flutterEngine: FlutterEngine) {
        val channel = MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            ChannelNames.locationNetwork
        )
        channel.setMethodCallHandler { call, result ->
            when (call.method) {
                "requestPermission" -> requestPermission(result)
                "getLocation" -> getLocation(result)
                "getNetworkStatus" -> result.success(getNetworkStatus())
                else -> result.notImplemented()
            }
        }
    }

    private fun hasLocationPermission(): Boolean =
        ContextCompat.checkSelfPermission(
            activity, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

    private fun requestPermission(result: MethodChannel.Result) {
        if (hasLocationPermission()) {
            result.success(true)
            return
        }
        pendingPermissionResult = result
        ActivityCompat.requestPermissions(
            activity,
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
            MainActivity.REQUEST_CODE_LOCATION_PERMISSION
        )
    }

    /** MainActivity.onRequestPermissionsResult isko call karta hai. */
    fun onPermissionResult(grantResults: IntArray) {
        val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
        pendingPermissionResult?.success(granted)
        pendingPermissionResult = null
    }

    private fun getLocation(result: MethodChannel.Result) {
        if (!hasLocationPermission()) {
            result.error("PERMISSION_DENIED", "Location permission nahi hai", null)
            return
        }
        val locationManager = activity.getSystemService(LocationManager::class.java)
        val provider = when {
            locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
            locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
            else -> null
        }
        if (provider == null) {
            result.error("LOCATION_DISABLED", "Koi location provider enabled nahi hai", null)
            return
        }

        // One-shot update — requestLocationUpdates + turant removeUpdates,
        // taaki koi continuous background listener register na rahe (API
        // 30+ ka getCurrentLocation() sabhi supported OS versions par nahi
        // hai, isliye yeh zyada compatible tareeka hai).
        var responded = false
        val listener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                if (responded) return
                responded = true
                locationManager.removeUpdates(this)
                result.success(locationToMap(location))
            }

            @Deprecated("Deprecated in API 29, but override still required pre-29")
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {
                if (responded) return
                responded = true
                locationManager.removeUpdates(this)
                result.error("LOCATION_DISABLED", "Provider band ho gaya", null)
            }
        }

        try {
            locationManager.requestLocationUpdates(provider, 0L, 0f, listener, activity.mainLooper)
        } catch (e: SecurityException) {
            result.error("PERMISSION_DENIED", e.message, null)
            return
        }

        // Timeout — agar 10 second mein koi fix na mile to last-known
        // location fallback try karte hain.
        activity.window.decorView.postDelayed({
            if (!responded) {
                responded = true
                locationManager.removeUpdates(listener)
                @Suppress("MissingPermission")
                val last = locationManager.getLastKnownLocation(provider)
                if (last != null) {
                    result.success(locationToMap(last))
                } else {
                    result.error("TIMEOUT", "Location fix nahi mila", null)
                }
            }
        }, 10_000)
    }

    private fun locationToMap(location: Location): Map<String, Any> = mapOf(
        "latitude" to location.latitude,
        "longitude" to location.longitude,
        "accuracy_m" to location.accuracy.toDouble(),
        "timestamp" to isoFormat.format(Date(location.time)),
        "source" to location.provider.orEmpty()
    )

    private fun getNetworkStatus(): Map<String, Any?> {
        val connectivityManager = activity.getSystemService(ConnectivityManager::class.java)
        val network = connectivityManager.activeNetwork
        val capabilities = network?.let { connectivityManager.getNetworkCapabilities(it) }

        val connected = capabilities?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        val connectionType = when {
            capabilities == null -> "NONE"
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "WIFI"
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "CELLULAR"
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ETHERNET"
            else -> "OTHER"
        }

        var ssid: String? = null
        if (connectionType == "WIFI" && hasLocationPermission()) {
            // SSID padhne ke liye location permission chahiye — Android
            // ka apna design (Wi-Fi se location infer ho sakti hai
            // isliye isko location-sensitive data treat kiya gaya hai).
            val wifiManager = activity.applicationContext.getSystemService(WifiManager::class.java)
            val rawSsid = wifiManager?.connectionInfo?.ssid
            ssid = rawSsid?.trim('"').takeIf { it != "<unknown ssid>" }
        }

        return mapOf(
            "connected" to connected,
            "ssid" to ssid,
            "connection_type" to connectionType,
            "timestamp" to isoFormat.format(Date())
        )
    }
}
