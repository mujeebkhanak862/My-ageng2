package com.deviceagent.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Base64
import android.provider.DocumentsContract
import androidx.documentfile.provider.DocumentFile
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File

/**
 * Native side of `ChannelNames.files` — matches Dart's `FilesBridge`.
 * Section 3.4 (Data Channel) ke upload/download/file-get actions isi ke
 * upar layer karte hain.
 *
 * Do modes:
 *  - Plain relative path -> app-sandbox root (`getExternalFilesDir`,
 *    Android 10+ par koi extra runtime permission nahi chahiye).
 *  - `content://...` URI -> user ne `pickDirectory()` se jo SAF tree
 *    choose ki thi, uske andar `DocumentFile` operations.
 *
 * Dono modes mein path-traversal (`..` se sandbox se bahar nikalna)
 * explicitly reject hota hai.
 */
class FilesHandler(private val activity: MainActivity) {

    private var pendingPickResult: MethodChannel.Result? = null
    private var pickedTreeUri: Uri? = null

    private val sandboxRoot: File
        get() = activity.getExternalFilesDir(null) ?: activity.filesDir

    fun register(flutterEngine: FlutterEngine) {
        val channel = MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            ChannelNames.files
        )
        channel.setMethodCallHandler { call, result ->
            when (call.method) {
                "getAllowedRoot" -> result.success(sandboxRoot.absolutePath)
                "listDirectory" -> listDirectory(call.argument("path") ?: "", result)
                "readFile" -> readFile(call.argument("path") ?: "", result)
                "writeFile" -> writeFile(
                    call.argument("path") ?: "",
                    call.argument("data") ?: "",
                    result
                )
                "deleteFile" -> deleteFile(call.argument("path") ?: "", result)
                "pickDirectory" -> pickDirectory(result)
                else -> result.notImplemented()
            }
        }
    }

    /** SAF folder-picker — user jo directory choose kare uska persistent access milta hai. */
    private fun pickDirectory(result: MethodChannel.Result) {
        pendingPickResult = result
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
        activity.startActivityForResult(intent, MainActivity.REQUEST_CODE_PICK_DIRECTORY)
    }

    /** MainActivity.onActivityResult isko call karta hai jab folder chun li jaaye. */
    fun onDirectoryPicked(resultCode: Int, data: Intent?) {
        if (resultCode == Activity.RESULT_OK && data?.data != null) {
            val uri = data.data!!
            activity.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            pickedTreeUri = uri
            pendingPickResult?.success(uri.toString())
        } else {
            pendingPickResult?.success(null)
        }
        pendingPickResult = null
    }

    /**
     * **Real bug jo yahan tha**: `target.path.startsWith(rootCanonical.path)`
     * sirf STRING prefix check karta hai, asal directory-boundary nahi.
     * Agar `sandboxRoot` ka canonical path ho `/.../files`, to koi bhi
     * SIBLING directory jiska naam bhi isi prefix se shuru ho — jaise
     * `/.../files_backup` ya `/.../files2` (agar OS/koi aur app ne
     * accidentally bana di ho) — is check ko galti se PASS kar jaata,
     * kyunki `"/.../files2".startsWith("/.../files")` bhi `true` hai,
     * chahe `files2` `files` ke andar na ho. Yeh classic path-traversal
     * check bug hai (CWE-22 se related pattern) — sahi fix hamesha yeh
     * check karna hai ke target ya to root ke EXACTLY barabar ho, ya
     * root + separator se shuru ho.
     */
    private fun resolveSandboxFile(relativePath: String): File? {
        val target = File(sandboxRoot, relativePath).canonicalFile
        val rootCanonical = sandboxRoot.canonicalFile
        val isWithinRoot = target == rootCanonical ||
            target.path.startsWith(rootCanonical.path + File.separator)
        return if (isWithinRoot) target else null
    }

    private fun listDirectory(path: String, result: MethodChannel.Result) {
        if (path.startsWith("content://")) {
            val dir = DocumentFile.fromTreeUri(activity, Uri.parse(path))
            if (dir == null || !dir.isDirectory) {
                result.error("NOT_FOUND", "Directory nahi mili", null)
                return
            }
            val entries = dir.listFiles().map {
                mapOf(
                    "name" to (it.name ?: ""),
                    "isDirectory" to it.isDirectory,
                    "size" to it.length(),
                    "modifiedAt" to it.lastModified(),
                    "path" to it.uri.toString()
                )
            }
            result.success(entries)
            return
        }

        val dir = resolveSandboxFile(path)
        if (dir == null || !dir.isDirectory) {
            result.error("NOT_FOUND", "Directory nahi mili ya sandbox se bahar hai", null)
            return
        }
        val entries = (dir.listFiles() ?: emptyArray()).map {
            mapOf(
                "name" to it.name,
                "isDirectory" to it.isDirectory,
                "size" to it.length(),
                "modifiedAt" to it.lastModified(),
                "path" to it.relativeTo(sandboxRoot).path
            )
        }
        result.success(entries)
    }

    private fun readFile(path: String, result: MethodChannel.Result) {
        try {
            val bytes = if (path.startsWith("content://")) {
                activity.contentResolver.openInputStream(Uri.parse(path))?.use { it.readBytes() }
            } else {
                val file = resolveSandboxFile(path)
                if (file == null || !file.isFile) null else file.readBytes()
            }
            if (bytes == null) {
                result.error("NOT_FOUND", "File nahi mili", null)
            } else {
                result.success(Base64.encodeToString(bytes, Base64.NO_WRAP))
            }
        } catch (e: Exception) {
            result.error("READ_FAILED", e.message, null)
        }
    }

    private fun writeFile(path: String, base64Data: String, result: MethodChannel.Result) {
        try {
            val bytes = Base64.decode(base64Data, Base64.NO_WRAP)
            if (path.startsWith("content://")) {
                activity.contentResolver.openOutputStream(Uri.parse(path))?.use {
                    it.write(bytes)
                }
            } else {
                // Pehle yahan `resolveSandboxFile()` wala hi buggy prefix
                // check duplicate/inline tha — ab shared, fixed function
                // reuse karte hain (DRY, aur dono jagah ek saath sahi rehta
                // hai future mein).
                val file = resolveSandboxFile(path)
                if (file == null) {
                    result.error("FORBIDDEN", "Sandbox se bahar likhna mana hai", null)
                    return
                }
                file.parentFile?.mkdirs()
                file.writeBytes(bytes)
            }
            result.success(true)
        } catch (e: Exception) {
            result.error("WRITE_FAILED", e.message, null)
        }
    }

    private fun deleteFile(path: String, result: MethodChannel.Result) {
        try {
            val ok = if (path.startsWith("content://")) {
                DocumentsContract.deleteDocument(activity.contentResolver, Uri.parse(path))
            } else {
                resolveSandboxFile(path)?.delete() ?: false
            }
            result.success(ok)
        } catch (e: Exception) {
            result.error("DELETE_FAILED", e.message, null)
        }
    }
}
