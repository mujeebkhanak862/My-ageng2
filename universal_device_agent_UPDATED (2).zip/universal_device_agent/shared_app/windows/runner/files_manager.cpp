// files_manager.cpp
#include "files_manager.h"

#include <flutter/method_channel.h>
#include <flutter/standard_method_codec.h>

#include <shobjidl.h>
#include <wincrypt.h>
#include <wrl/client.h>

#include <filesystem>
#include <fstream>
#include <memory>
#include <string>
#include <vector>

namespace fs = std::filesystem;

namespace {
constexpr char kChannel[] = "device_agent/files";

// Default sandbox root — %LOCALAPPDATA%\DeviceAgent\sandbox. Doc ke
// "allowed-root filesystem sandbox" (Section 6.7 file-list comment) ka
// Windows-equivalent; koi extra Windows permission nahi chahiye is
// folder ke liye kyunki yeh already user-writable hai.
fs::path SandboxRoot() {
  wchar_t* local_app_data = nullptr;
  fs::path root;
  if (SUCCEEDED(SHGetKnownFolderPath(FOLDERID_LocalAppData, 0, nullptr,
                                      &local_app_data))) {
    root = fs::path(local_app_data) / L"DeviceAgent" / L"sandbox";
    CoTaskMemFree(local_app_data);
  } else {
    root = fs::temp_directory_path() / L"DeviceAgentSandbox";
  }
  std::error_code ec;
  fs::create_directories(root, ec);
  return root;
}

// Path traversal protection: relative_path ko sandbox root ke andar
// resolve karta hai, agar bahar nikal jaaye to empty path return karta
// hai (caller ise "forbidden" treat kare).
//
// User `pickDirectory()` se jo folder choose kare, uska absolute path
// yahan "granted roots" mein add ho jaata hai — taaki poore device
// storage ko bhi (jaise C:\ ya koi bhi user-chuni hui drive/folder)
// isi Files capability se browse kiya ja sake, sandbox root tak
// limited rahe bina. Yeh list sirf is process ke lifetime tak rehti
// hai (persist nahi hoti) — har naye session mein dobara pick karna
// padega, jo intentional hai (Section 3 ke scoped-permission spirit
// ke mutabiq, ek baar di gayi broad access hamesha ke liye silently
// yaad nahi rehni chahiye).
std::vector<fs::path> g_granted_roots;

// **Real bug jo yahan tha (Android `FilesHandler.kt` mein bhi wahi bug
// tha, dono jagah fix kiya)**: neeche do jagah bare string-prefix
// comparison tha (`compare(0, root_str.size(), root_str) == 0`), boundary
// check ke bina. Iska matlab: agar sandbox root ho
// `C:\...\DeviceAgent\sandbox`, to ek SIBLING folder jiska naam bhi isi
// prefix se shuru ho — jaise `C:\...\DeviceAgent\sandbox_other` — is
// check ko galti se pass kar jaata, kyunki string-wise woh prefix match
// kar raha hota hai, chahe woh asal mein us directory ke andar na ho.
// Yeh helper sahi boundary check karta hai: target ya to root ke
// EXACTLY barabar ho, ya root + path-separator se shuru ho.
bool IsPathUnder(const std::wstring& target_str, const std::wstring& root_str) {
  if (target_str == root_str) return true;
  if (target_str.size() <= root_str.size()) return false;
  if (target_str.compare(0, root_str.size(), root_str) != 0) return false;
  wchar_t next = target_str[root_str.size()];
  return next == L'\\' || next == L'/';
}

fs::path ResolveSandboxed(const std::string& relative_path) {
  fs::path root = fs::weakly_canonical(SandboxRoot());

  fs::path requested(relative_path);
  if (requested.is_absolute()) {
    // Absolute path — sirf tab allowed jab woh sandbox root ke andar ho
    // YA user ne explicitly pickDirectory() se grant kiya ho.
    fs::path target = fs::weakly_canonical(requested);
    auto target_str = target.wstring();

    auto is_under = [&](const fs::path& allowed_root) {
      return IsPathUnder(target_str, fs::weakly_canonical(allowed_root).wstring());
    };

    if (is_under(root)) return target;
    for (auto& granted : g_granted_roots) {
      if (is_under(granted)) return target;
    }
    return {};
  }

  // Relative path — hamesha sandbox root ke andar resolve hota hai
  // (existing default-mode behavior).
  fs::path target = fs::weakly_canonical(root / relative_path);
  if (!IsPathUnder(target.wstring(), root.wstring())) {
    return {};
  }
  return target;
}

std::string Base64Encode(const std::vector<unsigned char>& bytes) {
  DWORD out_len = 0;
  CryptBinaryToStringA(bytes.data(), static_cast<DWORD>(bytes.size()),
                        CRYPT_STRING_BASE64 | CRYPT_STRING_NOCRLF, nullptr,
                        &out_len);
  std::string out(out_len, '\0');
  CryptBinaryToStringA(bytes.data(), static_cast<DWORD>(bytes.size()),
                        CRYPT_STRING_BASE64 | CRYPT_STRING_NOCRLF, out.data(),
                        &out_len);
  out.resize(out_len > 0 ? out_len - 1 : 0);  // trailing NUL trim
  return out;
}

std::vector<unsigned char> Base64Decode(const std::string& b64) {
  DWORD out_len = 0;
  CryptStringToBinaryA(b64.c_str(), static_cast<DWORD>(b64.size()),
                        CRYPT_STRING_BASE64, nullptr, &out_len, nullptr,
                        nullptr);
  std::vector<unsigned char> out(out_len);
  CryptStringToBinaryA(b64.c_str(), static_cast<DWORD>(b64.size()),
                        CRYPT_STRING_BASE64, out.data(), &out_len, nullptr,
                        nullptr);
  return out;
}

// Native folder picker — IFileDialog with FOS_PICKFOLDERS, broader
// user-granted access ke liye (sandbox root se bahar).
std::string PickDirectory(HWND owner) {
  Microsoft::WRL::ComPtr<IFileDialog> dialog;
  if (FAILED(CoCreateInstance(CLSID_FileOpenDialog, nullptr, CLSCTX_INPROC_SERVER,
                               IID_PPV_ARGS(&dialog)))) {
    return "";
  }
  DWORD flags = 0;
  dialog->GetOptions(&flags);
  dialog->SetOptions(flags | FOS_PICKFOLDERS);

  if (FAILED(dialog->Show(owner))) return "";

  Microsoft::WRL::ComPtr<IShellItem> item;
  if (FAILED(dialog->GetResult(&item))) return "";

  PWSTR path_wide = nullptr;
  if (FAILED(item->GetDisplayName(SIGDN_FILESYSPATH, &path_wide))) return "";

  int size = WideCharToMultiByte(CP_UTF8, 0, path_wide, -1, nullptr, 0,
                                  nullptr, nullptr);
  std::string result(size, 0);
  WideCharToMultiByte(CP_UTF8, 0, path_wide, -1, result.data(), size,
                       nullptr, nullptr);
  CoTaskMemFree(path_wide);
  if (!result.empty() && result.back() == '\0') result.pop_back();
  return result;
}
}  // namespace

void FilesManager::Register(flutter::FlutterEngine* engine, HWND window_handle) {
  auto channel = std::make_shared<flutter::MethodChannel<flutter::EncodableValue>>(
      engine->messenger(), kChannel,
      &flutter::StandardMethodCodec::GetInstance());

  channel->SetMethodCallHandler(
      [channel, window_handle](
          const flutter::MethodCall<flutter::EncodableValue>& call,
          std::unique_ptr<flutter::MethodResult<flutter::EncodableValue>> result) {
        const auto* args = std::get_if<flutter::EncodableMap>(call.arguments());
        auto get_string = [&](const char* key) -> std::string {
          if (!args) return "";
          auto it = args->find(flutter::EncodableValue(key));
          if (it == args->end()) return "";
          if (auto v = std::get_if<std::string>(&it->second)) return *v;
          return "";
        };

        if (call.method_name() == "getAllowedRoot") {
          result->Success(flutter::EncodableValue(SandboxRoot().string()));

        } else if (call.method_name() == "listDirectory") {
          fs::path dir = ResolveSandboxed(get_string("path"));
          std::error_code ec;
          if (dir.empty() || !fs::is_directory(dir, ec)) {
            result->Error("NOT_FOUND", "Directory nahi mili ya sandbox se bahar hai");
            return;
          }
          flutter::EncodableList entries;
          for (auto& entry : fs::directory_iterator(dir, ec)) {
            flutter::EncodableMap m;
            m[flutter::EncodableValue("name")] =
                flutter::EncodableValue(entry.path().filename().string());
            m[flutter::EncodableValue("isDirectory")] =
                flutter::EncodableValue(entry.is_directory());
            m[flutter::EncodableValue("size")] = flutter::EncodableValue(
                static_cast<int64_t>(entry.is_regular_file() ? entry.file_size() : 0));
            // Absolute path — chahe sandbox ho ya user-granted external
            // root, caller isi string ko wapas readFile/writeFile mein
            // pass kar sakta hai bina kisi ambiguity ke.
            m[flutter::EncodableValue("path")] =
                flutter::EncodableValue(entry.path().string());
            entries.push_back(flutter::EncodableValue(m));
          }
          result->Success(flutter::EncodableValue(entries));

        } else if (call.method_name() == "readFile") {
          fs::path file = ResolveSandboxed(get_string("path"));
          std::error_code ec;
          if (file.empty() || !fs::is_regular_file(file, ec)) {
            result->Error("NOT_FOUND", "File nahi mili");
            return;
          }
          std::ifstream in(file, std::ios::binary);
          std::vector<unsigned char> bytes(
              (std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
          result->Success(flutter::EncodableValue(Base64Encode(bytes)));

        } else if (call.method_name() == "writeFile") {
          fs::path file = ResolveSandboxed(get_string("path"));
          if (file.empty()) {
            result->Error("FORBIDDEN", "Sandbox se bahar likhna mana hai");
            return;
          }
          std::error_code ec;
          fs::create_directories(file.parent_path(), ec);
          auto bytes = Base64Decode(get_string("data"));
          std::ofstream out(file, std::ios::binary);
          out.write(reinterpret_cast<const char*>(bytes.data()), bytes.size());
          result->Success(flutter::EncodableValue(true));

        } else if (call.method_name() == "deleteFile") {
          fs::path file = ResolveSandboxed(get_string("path"));
          std::error_code ec;
          bool ok = !file.empty() && fs::remove(file, ec);
          result->Success(flutter::EncodableValue(ok));

        } else if (call.method_name() == "pickDirectory") {
          std::string picked = PickDirectory(window_handle);
          if (picked.empty()) {
            result->Success();
          } else {
            g_granted_roots.push_back(fs::path(picked));
            result->Success(flutter::EncodableValue(picked));
          }

        } else {
          result->NotImplemented();
        }
      });
}
