// screen_capture_manager.cpp
#include "screen_capture_manager.h"

#include <flutter/standard_method_codec.h>
#include <wincodec.h>
#include <winrt/Windows.Foundation.h>
#include <winrt/Windows.Graphics.DirectX.h>

#include <d3d11.h>
#include <windows.graphics.capture.interop.h>

using namespace winrt::Windows::Graphics::Capture;
using namespace winrt::Windows::Graphics::DirectX;
using namespace winrt::Windows::Graphics::DirectX::Direct3D11;

namespace {
constexpr char kMethodChannel[] = "device_agent/screen_capture";
constexpr char kEventChannel[] = "device_agent/screen_live_stream";

// D3D11 device banata hai aur usko WinRT IDirect3DDevice mein wrap karta
// hai — GraphicsCaptureItem isi device ke against frames deta hai.
IDirect3DDevice CreateD3DDevice() {
  Microsoft::WRL::ComPtr<ID3D11Device> d3d_device;
  D3D11CreateDevice(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr,
                     D3D11_CREATE_DEVICE_BGRA_SUPPORT, nullptr, 0,
                     D3D11_SDK_VERSION, &d3d_device, nullptr, nullptr);

  Microsoft::WRL::ComPtr<IDXGIDevice> dxgi_device;
  d3d_device.As(&dxgi_device);

  winrt::com_ptr<::IInspectable> inspectable;
  winrt::check_hresult(CreateDirect3D11DeviceFromDXGIDevice(
      dxgi_device.Get(),
      reinterpret_cast<::IInspectable**>(winrt::put_abi(inspectable))));
  return inspectable.as<IDirect3DDevice>();
}

// HWND se GraphicsCaptureItem banane ke liye interop factory chahiye —
// yeh WinRT API standalone HWND capture ke liye is tarah expose hoti hai.
GraphicsCaptureItem CreateCaptureItemForPrimaryMonitor() {
  auto factory = winrt::get_activation_factory<
      GraphicsCaptureItem, IGraphicsCaptureItemInterop>();
  HMONITOR monitor = MonitorFromWindow(GetDesktopWindow(), MONITOR_DEFAULTTOPRIMARY);
  GraphicsCaptureItem item{nullptr};
  winrt::check_hresult(factory->CreateForMonitor(
      monitor, winrt::guid_of<GraphicsCaptureItem>(),
      winrt::put_abi(item)));
  return item;
}

// WIC ka use karke ek BGRA texture ko JPEG bytes mein encode karta hai.
std::vector<uint8_t> EncodeTextureAsJpeg(ID3D11Texture2D* texture,
                                          uint32_t width, uint32_t height) {
  std::vector<uint8_t> out;

  Microsoft::WRL::ComPtr<IWICImagingFactory> wic_factory;
  CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER,
                    IID_PPV_ARGS(&wic_factory));

  Microsoft::WRL::ComPtr<IStream> stream;
  CreateStreamOnHGlobal(nullptr, TRUE, &stream);

  Microsoft::WRL::ComPtr<IWICBitmapEncoder> encoder;
  wic_factory->CreateEncoder(GUID_ContainerFormatJpeg, nullptr, &encoder);
  encoder->Initialize(stream.Get(), WICBitmapEncoderNoCache);

  Microsoft::WRL::ComPtr<IWICBitmapFrameEncode> frame;
  encoder->CreateNewFrame(&frame, nullptr);
  frame->Initialize(nullptr);
  frame->SetSize(width, height);
  WICPixelFormatGUID format = GUID_WICPixelFormat32bppBGRA;
  frame->SetPixelFormat(&format);

  D3D11_MAPPED_SUBRESOURCE mapped{};
  Microsoft::WRL::ComPtr<ID3D11Device> device;
  texture->GetDevice(&device);
  Microsoft::WRL::ComPtr<ID3D11DeviceContext> context;
  device->GetImmediateContext(&context);

  if (SUCCEEDED(context->Map(texture, 0, D3D11_MAP_READ, 0, &mapped))) {
    frame->WritePixels(height, mapped.RowPitch,
                        mapped.RowPitch * height,
                        static_cast<BYTE*>(mapped.pData));
    context->Unmap(texture, 0);
  }

  frame->Commit();
  encoder->Commit();

  STATSTG stats;
  stream->Stat(&stats, STATFLAG_NONAME);
  ULONG size = static_cast<ULONG>(stats.cbSize.QuadPart);
  out.resize(size);
  LARGE_INTEGER zero{};
  stream->Seek(zero, STREAM_SEEK_SET, nullptr);
  ULONG read = 0;
  stream->Read(out.data(), size, &read);
  out.resize(read);
  return out;
}
}  // namespace

void ScreenCaptureManager::Register(flutter::FlutterEngine* engine,
                                     HWND window_handle) {
  // Deliberately leaked (lives for the process lifetime) — same pattern
  // Flutter's own generated plugin registrants use for singleton managers.
  new ScreenCaptureManager(engine, window_handle);
}

ScreenCaptureManager::ScreenCaptureManager(flutter::FlutterEngine* engine,
                                            HWND window_handle)
    : window_handle_(window_handle) {
  method_channel_ =
      std::make_unique<flutter::MethodChannel<flutter::EncodableValue>>(
          engine->messenger(), kMethodChannel,
          &flutter::StandardMethodCodec::GetInstance());
  method_channel_->SetMethodCallHandler(
      [this](const auto& call, auto result) {
        HandleMethodCall(call, std::move(result));
      });

  event_channel_ =
      std::make_unique<flutter::EventChannel<flutter::EncodableValue>>(
          engine->messenger(), kEventChannel,
          &flutter::StandardMethodCodec::GetInstance());
  event_channel_->SetStreamHandler(
      std::make_unique<flutter::StreamHandlerFunctions<flutter::EncodableValue>>(
          [this](const flutter::EncodableValue*,
                 std::unique_ptr<flutter::EventSink<flutter::EncodableValue>> sink)
              -> std::unique_ptr<flutter::StreamHandlerError<flutter::EncodableValue>> {
            event_sink_ = std::move(sink);
            StartStream();
            return nullptr;
          },
          [this](const flutter::EncodableValue*)
              -> std::unique_ptr<flutter::StreamHandlerError<flutter::EncodableValue>> {
            StopStream();
            event_sink_ = nullptr;
            return nullptr;
          }));
}

ScreenCaptureManager::~ScreenCaptureManager() { StopStream(); }

void ScreenCaptureManager::HandleMethodCall(
    const flutter::MethodCall<flutter::EncodableValue>& call,
    std::unique_ptr<flutter::MethodResult<flutter::EncodableValue>> result) {
  if (call.method_name() == "requestPermission") {
    result->Success(flutter::EncodableValue(EnsureSessionStarted()));
  } else if (call.method_name() == "captureScreenshot") {
    if (!EnsureSessionStarted()) {
      result->Error("NOT_READY", "Capture session start nahi ho saka");
      return;
    }
    auto jpeg = CaptureFrameAsJpeg();
    // Base64 encode karke Dart ko bhejna (Android/Linux ke saath consistent).
    static const char* b64_chars =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    std::string encoded;
    size_t i = 0;
    while (i + 2 < jpeg.size()) {
      uint32_t n = (jpeg[i] << 16) | (jpeg[i + 1] << 8) | jpeg[i + 2];
      encoded += b64_chars[(n >> 18) & 0x3F];
      encoded += b64_chars[(n >> 12) & 0x3F];
      encoded += b64_chars[(n >> 6) & 0x3F];
      encoded += b64_chars[n & 0x3F];
      i += 3;
    }
    result->Success(flutter::EncodableValue(encoded));
  } else if (call.method_name() == "stopStream") {
    StopStream();
    result->Success();
  } else {
    result->NotImplemented();
  }
}

bool ScreenCaptureManager::EnsureSessionStarted() {
  std::lock_guard<std::mutex> lock(mutex_);
  if (session_ready_) return true;
  try {
    d3d_device_ = CreateD3DDevice();
    capture_item_ = CreateCaptureItemForPrimaryMonitor();
    auto size = capture_item_.Size();
    frame_pool_ = Direct3D11CaptureFramePool::Create(
        d3d_device_, DirectXPixelFormat::B8G8R8A8UIntNormalized, 2, size);
    capture_session_ = frame_pool_.CreateCaptureSession(capture_item_);
    session_ready_ = true;
    return true;
  } catch (...) {
    return false;
  }
}

std::vector<uint8_t> ScreenCaptureManager::CaptureFrameAsJpeg() {
  if (!session_ready_) return {};
  auto frame = frame_pool_.TryGetNextFrame();
  if (!frame) return {};

  auto surface = frame.Surface();
  auto access = surface.as<Windows::Graphics::DirectX::Direct3D11::IDirect3DDxgiInterfaceAccess>();
  Microsoft::WRL::ComPtr<ID3D11Texture2D> texture;
  access->GetInterface(IID_PPV_ARGS(&texture));

  D3D11_TEXTURE2D_DESC desc;
  texture->GetDesc(&desc);
  return EncodeTextureAsJpeg(texture.Get(), desc.Width, desc.Height);
}

void ScreenCaptureManager::StartStream() {
  if (!EnsureSessionStarted()) return;
  streaming_ = true;
  capture_session_.StartCapture();
  frame_pool_.FrameArrived(
      {this, &ScreenCaptureManager::OnFrameArrived});
}

void ScreenCaptureManager::StopStream() {
  streaming_ = false;
  if (capture_session_) {
    capture_session_.Close();
  }
  if (frame_pool_) {
    frame_pool_.Close();
  }
  session_ready_ = false;
}

void ScreenCaptureManager::OnFrameArrived(
    Direct3D11CaptureFramePool const& sender,
    winrt::Windows::Foundation::IInspectable const&) {
  if (!streaming_ || !event_sink_) return;
  auto jpeg = CaptureFrameAsJpeg();
  if (jpeg.empty()) return;

  static const char* b64_chars =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  std::string encoded;
  size_t i = 0;
  while (i + 2 < jpeg.size()) {
    uint32_t n = (jpeg[i] << 16) | (jpeg[i + 1] << 8) | jpeg[i + 2];
    encoded += b64_chars[(n >> 18) & 0x3F];
    encoded += b64_chars[(n >> 12) & 0x3F];
    encoded += b64_chars[(n >> 6) & 0x3F];
    encoded += b64_chars[n & 0x3F];
    i += 3;
  }
  event_sink_->Success(flutter::EncodableValue(encoded));
}
