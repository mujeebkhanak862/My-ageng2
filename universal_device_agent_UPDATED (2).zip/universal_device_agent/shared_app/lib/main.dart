import 'package:flutter/material.dart';
import 'dart:async';
import 'config/app_config.dart';
import 'dashboard/home_dashboard.dart';
import 'dashboard/pairing_screen.dart';
import 'dashboard/permission_wizard.dart';
import 'platform_channels/platform_channel_bridge.dart';
import 'protocol/agent_connection.dart';
import 'protocol/api_client.dart';
import 'protocol/api_key.dart';

void main() {
  runApp(const DeviceAgentApp());
}

/// Full app shell: Pairing -> `POST /devices/pair` (server se bearer
/// token) -> AgentConnection start (background command-listener) ->
/// (first-time) Permission Wizard -> Home Dashboard.
///
/// **P0-03**: Control API ka URL ab build-time `--dart-define=
/// CONTROL_API_URL=...` se aata hai (`config/app_config.dart`), source
/// code mein hardcoded nahi. Poori guide: HOW_TO_CONNECT.md.
class DeviceAgentApp extends StatefulWidget {
  const DeviceAgentApp({super.key});

  @override
  State<DeviceAgentApp> createState() => _DeviceAgentAppState();
}

class _DeviceAgentAppState extends State<DeviceAgentApp> {
  // AppConfig.load() khud fail-fast hai (P0-03) — release build mein
  // agar koi non-localhost host plaintext http ke saath diya jaaye to
  // yahan turant `InsecureTransportConfigError` throw hoga (startup ke
  // waqt hi, koi command silently plaintext nahi jaayega).
  final AppConfig _config = AppConfig.load();

  late final DeviceAgentApiClient _api = DeviceAgentApiClient(
    baseUrl: _config.controlApiBaseUrl,
    activeApiKeyId: 'pending-setup',
  );

  AgentConnection? _agentConnection;
  String? _deviceId;
  ApiKeyScope? _setupScope;
  String? _pairingError;

  // Audit fix (P1-05 / Section 13 #6) — real lock-state reporting.
  final LockStateBridge _lockStateBridge = LockStateBridge();
  StreamSubscription<String>? _lockStateSubscription;

  /// Native side se abhi tak koi bhi state message aaya ho ya na aaya ho,
  /// AgentConnection ka `reportStatus()` sirf **valid, native-verified**
  /// values ke saath call hota hai — kabhi guess/fake nahi (agar
  /// `currentState()`/stream error de ya null aaye, seedha ignore karte
  /// hain, server apna optimistic connect-time default rakhta hai — dekho
  /// `agent_connection.dart` ka `reportStatus()` doc-comment).
  void _startLockStateReporting() {
    _lockStateBridge.currentState().then((state) {
      if (state != null) _agentConnection?.reportStatus(state: state);
    }).catchError((_) {
      // Native bridge is platform par implement nahi hui (ya
      // MissingPluginException) — chup rehte hain, server ka optimistic
      // default hi sahi rahega. Yeh koi crash-worthy cheez nahi.
    });

    _lockStateSubscription = _lockStateBridge.stateChanges().listen(
      (state) => _agentConnection?.reportStatus(state: state),
      onError: (_) {
        // Stream fail ho gaya (platform channel missing waghera) — bas
        // sun'na band kar dete hain, poll-jaisa koi fallback nahi banate
        // (fake/guessed lock-state bhejne se behtar hai kuch na bhejna).
      },
    );
  }

  Future<void> _onPaired(String pairingCode) async {
    try {
      // Section: pairing ke turant baad device server ke saath register
      // hota hai — yahi woh call hai jo pehle sirf locally generate hote
      // rehti thi (README mein "abhi sirf locally generate hota hai"
      // note tha) — ab poora loop close ho gaya.
      final result = await _api.pairDevice(
        pairingCode: pairingCode,
        deviceName: 'My Device', // TODO: user se naam poochna behtar UX hoga
      );
      final deviceId = result['device_id'] as String;
      final bearerToken = result['bearer_token'] as String;

      _api.setBearerToken(bearerToken);

      // AgentConnection start — yahi background listener hai jo server
      // se incoming commands sunega aur unhe already-bani capabilities
      // tak dispatch karega (lib/protocol/agent_connection.dart).
      // `_config.controlApiWsBaseUrl` — already ws/wss (P0-03; http ka
      // scheme mismatch ab yahan pahunchne se pehle hi handle ho chuka).
      _agentConnection = AgentConnection(
        wsBaseUrl: _config.controlApiWsBaseUrl,
        deviceId: deviceId,
        bearerToken: bearerToken,
      );
      await _agentConnection!.connect();
      _startLockStateReporting();

      setState(() {
        _deviceId = deviceId;
        _pairingError = null;
      });
    } catch (e) {
      setState(() => _pairingError = 'Pairing server se connect nahi ho saka: $e');
    }
  }

  @override
  void dispose() {
    _lockStateSubscription?.cancel();
    _agentConnection?.disconnect();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Universal Device Agent',
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
      home: _deviceId == null
          ? (_pairingError != null
              ? _PairingErrorScreen(
                  message: _pairingError!,
                  onRetry: () => setState(() => _pairingError = null),
                )
              : PairingScreen(onPaired: _onPaired))
          : (_setupScope == null
              ? PermissionWizard(
                  title: 'Setup Permissions',
                  onConfirm: (scope) => setState(() => _setupScope = scope),
                )
              : HomeDashboard(api: _api, deviceId: _deviceId!)),
    );
  }
}

class _PairingErrorScreen extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;
  const _PairingErrorScreen({required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(message, textAlign: TextAlign.center),
              const SizedBox(height: 16),
              FilledButton(onPressed: onRetry, child: const Text('Retry')),
            ],
          ),
        ),
      ),
    );
  }
}
