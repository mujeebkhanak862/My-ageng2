/// Core Protocol — WebSocket client
///
/// Do WebSocket channels use hote hain (Architecture v4, Section 2.3):
///   WS /sessions/{id}  → task_progress / switch_event jaise DeviceAgentEvent
///   WS /screen/{id}    → "Watch Live" ke baad continuous raw frames
library;

import 'dart:async';
import 'dart:convert';
import 'package:web_socket_channel/web_socket_channel.dart';

import 'event_envelope.dart';

/// P0-03 — defense-in-depth: agar caller galti se http(s) base URL pass
/// kar de (ws/wss ki jagah), yahan hi normalize kar dete hain, taaki
/// `WebSocketChannel.connect()` ko kabhi galat scheme na mile (jo
/// runtime error deta hai). `AppConfig` (config/app_config.dart) mein
/// yeh already sahi se derive hota hai — yeh sirf ek safety net hai.
Uri _asWsUri(Uri baseUrl) {
  if (baseUrl.scheme == 'ws' || baseUrl.scheme == 'wss') return baseUrl;
  final wsScheme = baseUrl.scheme == 'https' ? 'wss' : 'ws';
  return baseUrl.replace(scheme: wsScheme);
}

/// `WS /sessions/{id}` — Dashboard aur AI Verifier dono isi stream se
/// task_progress / switch_event events sunte hain.
class SessionEventChannel {
  final WebSocketChannel _channel;
  final _controller = StreamController<DeviceAgentEvent>.broadcast();

  SessionEventChannel._(this._channel) {
    _channel.stream.listen(
      (raw) {
        try {
          final json = jsonDecode(raw as String) as Map<String, dynamic>;
          _controller.add(DeviceAgentEvent.fromJson(json));
        } catch (_) {
          // Malformed frame — ignore rather than crash the UI stream.
        }
      },
      onDone: _controller.close,
      onError: _controller.addError,
    );
  }

  factory SessionEventChannel.connect(Uri wsBaseUrl, String sessionId) {
    final uri = _asWsUri(wsBaseUrl)
        .replace(path: '${wsBaseUrl.path}/sessions/$sessionId');
    return SessionEventChannel._(WebSocketChannel.connect(uri));
  }

  Stream<DeviceAgentEvent> get events => _controller.stream;

  Future<void> close() async {
    await _controller.close();
    await _channel.sink.close();
  }
}

/// `WS /screen/{id}` — sirf jab user "Watch Live" dabaye tab connect hota hai
/// (Section 2.1 — Live Video / Hybrid mode). Snapshot mode ke liye is channel
/// ki zaroorat nahi, wahan screenshots normal task_progress event ke saath
/// aati hain.
class LiveScreenChannel {
  final WebSocketChannel _channel;

  LiveScreenChannel._(this._channel);

  factory LiveScreenChannel.connect(Uri wsBaseUrl, String sessionId) {
    final uri =
        _asWsUri(wsBaseUrl).replace(path: '${wsBaseUrl.path}/screen/$sessionId');
    return LiveScreenChannel._(WebSocketChannel.connect(uri));
  }

  /// Raw frame bytes (jpeg/png chunks ya codec-dependent packets) —
  /// UI layer (task_monitor/) inhe render karta hai.
  Stream<dynamic> get frames => _channel.stream;

  /// Section 2.5 — task complete/paused hote hi yeh channel band hona
  /// chahiye, koi background leak nahi.
  Future<void> close() => _channel.sink.close();
}
