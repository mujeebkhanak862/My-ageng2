/// Device-side Agent Connection — Control API se persistent WebSocket
/// (`WS /devices/{id}/agent`). Yeh file poore system ka woh missing loop
/// band karti hai jo pehle nahi tha: "command server se aata hai ->
/// device par actually execute hota hai -> result wapas jaata hai".
///
/// `api_client.dart` sirf **bhejne** wala client tha (commands POST
/// karna); yeh file **sunne** wala side hai — background mein chalti hai
/// aur incoming commands ko already-bani capability bridges
/// (`platform_channel_bridge.dart`) tak route karti hai.
library;

import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/services.dart' show PlatformException;

import '../browser/cdp_client.dart';
import '../platform_channels/platform_channel_bridge.dart';
import 'command_envelope.dart';

/// P0-01 — device-local task state. Server (`control_api`) ke TaskRecord
/// ka mirror hai, lekin authoritative nahi — server hi source-of-truth
/// hai (`/commands` route invalid transitions ko device tak forward hi
/// nahi karta). Yeh sirf device-side execution ko gate karne ke liye hai:
/// "PAUSED task ke liye koi nayi action dispatch na ho" ka asal
/// enforcement yahi hota hai, kyunki device hi actual native call
/// (tap/swipe/screen etc.) karta hai.
enum _TaskLocalStatus { running, paused, stopped }

class _DeviceTaskState {
  _TaskLocalStatus status;
  int completedSteps;
  String? lastAction;

  _DeviceTaskState({this.status = _TaskLocalStatus.running, this.completedSteps = 0});

  Map<String, dynamic> toCheckpointJson() =>
      {'completed_steps': completedSteps, if (lastAction != null) 'last_action': lastAction};
}

/// P1-06 — jab koi capability genuinely device par implement hi nahi hai
/// (jaise abhi notifications/messaging — Android NotificationListenerService
/// jaisi native OS-level integration chahiye jo is round mein nahi bani).
/// Generic `UnimplementedError` ki jagah yeh throw karte hain taaki
/// caller ko ek structured, deterministic error mile — "no fake success":
/// koi bhi caller/AI kabhi confuse na ho ke shayad kaam kar gaya ho.
class CapabilityUnavailableException implements Exception {
  final String action;
  final String reason;
  CapabilityUnavailableException(this.action, this.reason);
  @override
  String toString() => 'CAPABILITY_UNAVAILABLE: "$action" — $reason';
}

/// Dispatch us waqt reject hui jab task PAUSED tha — real "no new actions
/// dispatch" enforcement (TASK-01).
class TaskPausedException implements Exception {
  final String taskId;
  TaskPausedException(this.taskId);
  @override
  String toString() => 'TASK_PAUSED: task "$taskId" paused hai, nayi action dispatch nahi hogi';
}

/// Dispatch us waqt reject hui jab task STOPPED tha — task khatam ho
/// chuka, koi aur action allowed nahi (TASK-03).
class TaskStoppedException implements Exception {
  final String taskId;
  TaskStoppedException(this.taskId);
  @override
  String toString() => 'TASK_STOPPED: task "$taskId" stop ho chuka hai';
}

class AgentConnection {
  final Uri wsBaseUrl;
  final String deviceId;
  final String bearerToken;

  WebSocket? _socket;
  Timer? _heartbeatTimer;
  final CommandDispatcher _dispatcher = CommandDispatcher();
  bool _shouldReconnect = true;

  AgentConnection({
    required this.wsBaseUrl,
    required this.deviceId,
    required this.bearerToken,
  });

  Future<void> connect() async {
    _shouldReconnect = true;
    await _connectOnce();
  }

  Future<void> _connectOnce() async {
    // P0-03 — defense-in-depth: agar caller galti se http(s) base URL
    // pass kar de, yahan normalize kar dete hain (dart:io ka
    // `WebSocket.connect` sirf ws/wss scheme accept karta hai — http(s)
    // dena runtime error hota, jo pehle silently reconnect-loop mein
    // chala jaata). `AppConfig` (config/app_config.dart) mein yeh
    // already sahi se derive hota hai — yeh sirf ek safety net hai.
    final normalizedBase = (wsBaseUrl.scheme == 'ws' || wsBaseUrl.scheme == 'wss')
        ? wsBaseUrl
        : wsBaseUrl.replace(scheme: wsBaseUrl.scheme == 'https' ? 'wss' : 'ws');
    final uri = normalizedBase.replace(path: '${normalizedBase.path}/devices/$deviceId/agent');
    try {
      _socket = await WebSocket.connect(
        uri.toString(),
        headers: {'Authorization': 'Bearer $bearerToken'},
      );
    } catch (_) {
      _scheduleReconnect();
      return;
    }

    _heartbeatTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      _send({'kind': 'heartbeat'});
    });

    _socket!.listen(
      (raw) => _onMessage(raw as String),
      onDone: _handleDisconnect,
      onError: (_) => _handleDisconnect(),
    );
  }

  void _handleDisconnect() {
    _heartbeatTimer?.cancel();
    _socket = null;
    if (_shouldReconnect) _scheduleReconnect();
  }

  void _scheduleReconnect() {
    // Section: background agent ko resilient hona chahiye — network
    // flicker par khud reconnect karta hai, exponential backoff ke
    // bajaye simple fixed delay (v1 ke liye kaafi hai).
    Timer(const Duration(seconds: 5), () {
      if (_shouldReconnect) _connectOnce();
    });
  }

  void disconnect() {
    _shouldReconnect = false;
    _heartbeatTimer?.cancel();
    _socket?.close();
    // Fix ke saath aaya cleanup — `_desktopCdp` (agar khula hai) ko bhi
    // band karte hain, warna WebSocket connection process lifetime tak
    // khuli reh jaati (poora agent disconnect ho jaaye tab bhi).
    _dispatcher._desktopCdp?.close();
  }

  void _send(Map<String, dynamic> message) {
    _socket?.add(jsonEncode(message));
  }

  /// P1-05 — device ki real (native-reported) lock/sleep/screen state
  /// server ko batata hai (`status_update` message —
  /// `control_api/lib/websocket/handlers.dart` isko handle karta hai).
  ///
  /// **Honest gap**: is round mein koi native platform-channel bridge
  /// nahi likha gaya jo actual OS lock-state detect kare (Android
  /// `KeyguardManager`, Windows session-lock APIs, waghera) — woh native
  /// Kotlin/C++ code hai. Yeh method sirf **pipe** hai — jab bhi woh
  /// native detection ban jaye, bas yahan se call karna hai, poora
  /// server-side handling (state update, activity log, gating) already
  /// ready hai. Is liye yeh method abhi is file mein kahin se automatically
  /// call nahi hota — fake/guessed state bhejna se behtar hai kuch na
  /// bhejna (server apna khud ka honest optimistic default rakhta hai
  /// jab tak asal data na aaye).
  ///
  /// `state` in mein se ek honi chahiye: `ONLINE_UNLOCKED`,
  /// `ONLINE_LOCKED`, `SCREEN_OFF`, `SLEEPING`, `OFFLINE`, `POWERED_OFF`.
  void reportStatus({required String state, int? batteryPercent}) {
    _send({
      'kind': 'status_update',
      'state': state,
      if (batteryPercent != null) 'battery_percent': batteryPercent,
    });
  }

  Future<void> _onMessage(String raw) async {
    Map<String, dynamic> msg;
    try {
      msg = jsonDecode(raw) as Map<String, dynamic>;
    } catch (_) {
      return;
    }
    if (msg['kind'] != 'command') return;

    final envelope = CommandEnvelope.fromJson(msg);

    if (envelope.capability == 'screen' && envelope.action == 'screen.watch_live') {
      await _startLiveStream(envelope);
      return;
    }
    if (envelope.capability == 'screen' && envelope.action == 'screen.stop_live') {
      await _dispatcher.dispatch(envelope);
      _send({'kind': 'command_result', 'request_id': envelope.requestId, 'result': {}});
      return;
    }

    final stopwatch = Stopwatch()..start();
    try {
      final result = await _dispatcher.dispatch(envelope);
      stopwatch.stop();

      // control.stop **aur control.pause** dono par, agar isi session ka
      // live-stream chal raha ho, usko bhi cancel karte hain (P1-03
      // acceptance: "Task complete/pause par auto-stop"). Stop ka case
      // pehle se tha (P0-01); pause missing tha — paused task ka screen
      // dekhte rehna bhi resource-waste hai jab koi naya action ho hi
      // nahi raha. Resume par live-stream **wapas apne aap shuru nahi**
      // hota (jaan-bujh kar) — user ko explicitly "Watch Live" dobara
      // dabana hoga, taaki koi surprise background stream na chale.
      if (envelope.capability == 'control' &&
          (envelope.action == 'control.stop' || envelope.action == 'control.pause')) {
        final sessionId = envelope.params['session_id'] as String?;
        if (sessionId != null && _liveStreamSessionId == sessionId) {
          await _liveStreamSub?.cancel();
          _liveStreamSub = null;
          _liveStreamSessionId = null;
          await _dispatcher.screenBridge.stopLiveStream();
        }
      }

      _send({
        'kind': 'command_result',
        'request_id': envelope.requestId,
        'result': result,
      });
      _sendTaskProgress(envelope, success: true, durationMs: stopwatch.elapsedMilliseconds);
    } on TaskPausedException catch (e) {
      _send({
        'kind': 'command_result',
        'request_id': envelope.requestId,
        'result': {'error_code': 'TASK_PAUSED', 'message': e.toString()},
      });
      // Paused/stopped-gate rejections khud task_progress steps nahi
      // hain (koi action actually chali hi nahi) — is liye progress event
      // nahi bhejte, sirf command_result se caller ko pata chal jaata hai.
    } on TaskStoppedException catch (e) {
      _send({
        'kind': 'command_result',
        'request_id': envelope.requestId,
        'result': {'error_code': 'TASK_STOPPED', 'message': e.toString()},
      });
    } on CapabilityUnavailableException catch (e) {
      // P1-06 — structured, deterministic "unavailable" — audit:
      // "Unsupported target => structured CAPABILITY_UNAVAILABLE... koi
      // fake success nahi." Generic exception-string se alag, taaki
      // caller programmatically detect kar sake ke yeh ek "feature nahi
      // hai" case hai, koi transient error nahi.
      stopwatch.stop();
      _send({
        'kind': 'command_result',
        'request_id': envelope.requestId,
        'result': {'error_code': 'CAPABILITY_UNAVAILABLE', 'message': e.reason},
      });
      _sendTaskProgress(envelope,
          success: false,
          description: 'Not available: ${e.action}',
          durationMs: stopwatch.elapsedMilliseconds);
    } on PlatformException catch (e) {
      // P1-07 — native platform-channel code (location/network/screen/
      // contacts, waghera) jab ek coded error deta hai (jaise
      // "PERMISSION_DENIED", "LOCATION_DISABLED"), Flutter use apne aap
      // `PlatformException.code` mein map kar deta hai. Pehle yahan yeh
      // generic `catch (e)` mein gir jaata tha — `e.toString()` ek
      // un-structured, hard-to-parse string ban jaata (audit:
      // "Permission denied explicit; location disabled explicit" — jo
      // pehle explicit nahi tha). Ab uska `.code` seedha `error_code`
      // ban ke jaata hai — koi bhi caller/AI programmatically handle kar
      // sakta hai (retry karna hai, permission maangni hai, ya bas
      // "unavailable" dikhana hai).
      stopwatch.stop();
      _send({
        'kind': 'command_result',
        'request_id': envelope.requestId,
        'result': {'error_code': e.code, 'message': e.message ?? 'Native error'},
      });
      _sendTaskProgress(envelope,
          success: false,
          description: 'Failed (${e.code}): ${envelope.action}',
          durationMs: stopwatch.elapsedMilliseconds);
    } catch (e) {
      stopwatch.stop();
      _send({
        'kind': 'command_result',
        'request_id': envelope.requestId,
        'result': {'error': e.toString()},
      });
      _sendTaskProgress(envelope,
          success: false, description: e.toString(), durationMs: stopwatch.elapsedMilliseconds);
    }
  }

  StreamSubscription<dynamic>? _liveStreamSub;
  String? _liveStreamSessionId;

  Future<void> _startLiveStream(CommandEnvelope envelope) async {
    final sessionId = envelope.params['session_id'] as String? ?? envelope.requestId;

    // Paused/stopped task par naya live stream bhi shuru nahi hona
    // chahiye — same gate jo baaki actions par lagta hai.
    try {
      _dispatcher.checkTaskGate(sessionId);
    } on TaskPausedException catch (e) {
      _send({
        'kind': 'command_result',
        'request_id': envelope.requestId,
        'result': {'error_code': 'TASK_PAUSED', 'message': e.toString()},
      });
      return;
    } on TaskStoppedException catch (e) {
      _send({
        'kind': 'command_result',
        'request_id': envelope.requestId,
        'result': {'error_code': 'TASK_STOPPED', 'message': e.toString()},
      });
      return;
    }

    await _liveStreamSub?.cancel();
    _liveStreamSessionId = sessionId;
    _liveStreamSub = _dispatcher.screenBridge.liveFrames().listen((frame) {
      _send({'kind': 'screen_frame', 'session_id': sessionId, 'data': frame});
    });
    _send({
      'kind': 'command_result',
      'request_id': envelope.requestId,
      'result': {'started': true},
    });
  }

  /// P1-04 — Task Progress Event Quality + Safe Metadata.
  ///
  /// Pehle yahan `'step': 0` **hardcoded** tha (kabhi increment hi nahi
  /// hota tha — koi bhi step number 0 hi bhejta, timeline reconstruct
  /// karna namumkin tha) aur `description` success par sirf action ka
  /// naam thi (jaise "input.tap" — kuch bhi useful nahi batata). Duration
  /// bilkul nahi thi.
  ///
  /// Ab:
  ///   - `step` — real, per-task incrementing counter (P0-01 ke
  ///     `_DeviceTaskState.completedSteps` se — wahi checkpoint jo
  ///     `control.resume` bhi use karta hai, single source of truth).
  ///   - `duration_ms` — dispatch mein laga waqt.
  ///   - `description` — safe, params-aware (coordinates, file paths,
  ///     URLs — **kabhi bhi typed text ya clipboard content nahi**,
  ///     sirf metadata jo timeline reconstruct karne ke liye kaafi hai
  ///     bina kisi sensitive payload ke — audit: "Never put message/file
  ///     contents into normal task logs").
  void _sendTaskProgress(CommandEnvelope envelope,
      {required bool success, String? description, int durationMs = 0}) {
    final sessionId = envelope.params['session_id'] as String?;
    if (sessionId == null) return; // sirf session-scoped commands ke liye
    final step = _dispatcher.currentStepFor(sessionId);
    _send({
      'kind': 'event',
      'session_id': sessionId,
      'protocol_version': CommandEnvelope.currentProtocolVersion,
      // Yahan se aage — jo bhi fields hain, yeh hubahu woh shape hai jo
      // Dart client's TaskProgressEvent.fromJson (event_envelope.dart)
      // expect karta hai. "type" yahan is *inner* event ka type hai
      // ("task_progress"), server ke WS-multiplexing "kind" se alag —
      // dono ko overload karna hi woh bug tha jo shuru mein tha.
      'type': 'task_progress',
      'step': step,
      'action': envelope.action,
      'description': description ?? describeActionSafely(envelope, success: success),
      'result': success ? 'success' : 'fail',
      'duration_ms': durationMs,
      'timestamp': DateTime.now().toUtc().toIso8601String(),
    });
  }

  /// P1-04 — safe, params-aware description. **Kabhi bhi typed text,
  /// clipboard content, ya message content nahi deta** — sirf metadata
  /// jo user ke actual data ko expose kiye bina timeline useful banata
  /// hai (coordinates, file paths, URLs, field labels — yeh sab already
  /// "kahan/kya action" batate hain, "kya data" nahi).
  ///
  /// Top-level function hai (class method nahi) taaki tests seedha isko
  /// call kar sakein bina poori `AgentConnection`/WebSocket setup kiye.
}

String describeActionSafely(CommandEnvelope envelope, {required bool success}) {
  if (!success) return 'Failed: ${envelope.action}';
  final p = envelope.params;
  switch (envelope.action) {
    case 'screen.capture':
      return 'Captured a screenshot';
    case 'screen.watch_live':
      return 'Started live screen stream';
    case 'screen.stop_live':
      return 'Stopped live screen stream';
    case 'input.tap':
      return 'Tapped at (${p['x']}, ${p['y']})';
    case 'input.swipe':
      return 'Swiped from (${p['x1']}, ${p['y1']}) to (${p['x2']}, ${p['y2']})';
    case 'input.type_text':
      // Kabhi actual text nahi — sirf length (kitna type hua, kya nahi).
      final len = (p['text'] as String?)?.length;
      return len != null ? 'Typed $len character(s)' : 'Typed text';
    case 'files.list':
      return 'Listed files at ${p['path']}';
    case 'files.read':
      return 'Read file at ${p['path'] ?? p['target_path']}';
    case 'files.write':
      return 'Wrote file at ${p['path'] ?? p['target_path']}';
    case 'files.delete':
      return 'Deleted file at ${p['path']}';
    case 'app_launcher.launch':
      return 'Launched app: ${p['identifier']}';
    case 'app_launcher.list':
      return 'Listed installed apps';
    case 'browser.navigate':
      return 'Navigated to ${p['url']}';
    case 'browser.click':
      return 'Clicked element: ${p['text']}';
    case 'browser.type_text':
      return 'Typed into field: ${p['field_label']}'; // field label hai, typed VALUE nahi
    case 'browser.read':
      return 'Read browser page content';
    case 'clipboard.read':
      return 'Read clipboard'; // content kabhi nahi
    case 'clipboard.write':
      return 'Wrote to clipboard'; // content kabhi nahi
    case 'data.upload':
      return 'Uploaded file to ${p['path'] ?? p['target_path']}';
    case 'data.download':
      return 'Downloaded file from ${p['path'] ?? p['target_path']}';
    case 'contacts.list':
      return 'Listed contacts'; // names/numbers kabhi nahi
    case 'control.pause':
      return 'Paused task';
    case 'control.resume':
      return 'Resumed task';
    case 'control.stop':
      return 'Stopped task';
    case 'control.switch':
      return 'Switched session mode';
    case 'location.refresh':
      return 'Refreshed location';
    case 'background.keepalive':
      return 'Background keepalive';
    default:
      return 'Performed ${envelope.action}';
  }
}

/// Ek `CommandEnvelope` ko actual native call mein convert karta hai —
/// already-bani `platform_channel_bridge.dart` ki classes use karte
/// hue. Yeh dispatcher hi hai jo "protocol" ko "asal device action" se
/// jodta hai.
class CommandDispatcher {
  final screenBridge = ScreenCaptureBridge();
  final inputBridge = InputBridge();
  final filesBridge = FilesBridge();
  final appLauncherBridge = AppLauncherBridge();
  final clipboardBridge = ClipboardBridge();
  final browserBridge = BrowserBridge();
  final locationNetworkBridge = LocationNetworkBridge();
  final contactsBridge = ContactsBridge();

  /// Fix — Windows/Linux ke liye. Session-scoped rakhte hain (naya
  /// connect() sirf tab jab pehli baar chahiye ho, ya purana connection
  /// mar chuka ho) — CDP ek stateful WebSocket hai, har command par
  /// dobara connect karna (a) slow hai aur (b) galat bhi, kyunki tab/page
  /// context reconnect karne se reset ho jaata.
  CdpClient? _desktopCdp;

  Future<CdpClient> _ensureDesktopBrowser() async {
    final existing = _desktopCdp;
    if (existing != null) return existing;
    // `launchDesktopBrowser()` best-effort hai — agar Chrome/Edge already
    // debug-port ke saath chal raha ho (jaise pichhle session se), yeh
    // launch call redundant hogi lekin harmless. **Honest caveat**: agar
    // browser already BINA debug-port ke chal raha ho, Chrome/Edge us
    // running instance ko naya `--remote-debugging-port` flag nahi
    // deta — sirf ek naya window khulta hai, debug port active nahi
    // hota. Is case mein user ko manually browser band karke dobara
    // try karna hoga. Yeh ek well-known Chrome/Edge behavior hai, is
    // code ka bug nahi — lekin explicitly yahan likha hai, chhupaya
    // nahi.
    await browserBridge.launchDesktopBrowser();
    // Chrome ko debug port par HTTP server start karne ke liye thoda
    // waqt chahiye hota hai.
    await Future<void>.delayed(const Duration(milliseconds: 800));
    final client = await CdpClient.connect(BrowserBridge.desktopDebugPort);
    _desktopCdp = client;
    return client;
  }

  /// P0-01 — session_id (== server ka taskId) se local task state.
  final Map<String, _DeviceTaskState> _tasks = {};

  _DeviceTaskState _taskFor(String sessionId) =>
      _tasks.putIfAbsent(sessionId, () => _DeviceTaskState());

  /// P1-04 — `_sendTaskProgress` ke liye public read-only accessor. Yeh
  /// wahi checkpoint counter hai jo `control.resume` bhi return karta
  /// hai (`_DeviceTaskState.completedSteps`) — single source of truth,
  /// progress-event step numbering aur resume-checkpoint kabhi drift
  /// nahi karenge.
  int currentStepFor(String sessionId) => _taskFor(sessionId).completedSteps;

  /// Kisi bhi session-scoped, non-control action se pehle call hota hai.
  /// PAUSED/STOPPED task par throw karta hai — yehi asal jagah hai jahan
  /// "PAUSED task par koi nayi action dispatch nahi" enforce hota hai,
  /// kyunki yahi wo layer hai jo actual native call karne se pehle aata
  /// hai.
  void checkTaskGate(String? sessionId) {
    if (sessionId == null) return; // session-scoped nahi — gate apply nahi hoti
    final task = _tasks[sessionId];
    if (task == null) return; // abhi tak koi task record nahi — pehli action hai
    if (task.status == _TaskLocalStatus.paused) {
      throw TaskPausedException(sessionId);
    }
    if (task.status == _TaskLocalStatus.stopped) {
      throw TaskStoppedException(sessionId);
    }
  }

  Future<Map<String, dynamic>> dispatch(CommandEnvelope envelope) async {
    final p = envelope.params;
    final sessionId = p['session_id'] as String?;

    // control.* apni khud ki state-machine logic switch-case ke andar
    // handle karta hai (neeche) — baaki sab session-scoped actions gate
    // se guzarte hain. `screen.stop_live` bhi exempt hai — yeh khud ek
    // cleanup/cancellation action hai, isko PAUSED/STOPPED task par bhi
    // chalne dena chahiye (warna stream kabhi band hi nahi ho payega).
    if (envelope.capability != 'control' && envelope.action != 'screen.stop_live') {
      checkTaskGate(sessionId);
    }

    final result = await _dispatchInner(envelope, p);

    // Kamyaab execution ke baad checkpoint (step count) aage badhao —
    // control.resume isi checkpoint se "continue" ka signal deta hai.
    if (sessionId != null && envelope.capability != 'control') {
      final task = _taskFor(sessionId);
      task.completedSteps += 1;
      task.lastAction = envelope.action;
    }
    return result;
  }

  Future<Map<String, dynamic>> _dispatchInner(
      CommandEnvelope envelope, Map<String, dynamic> p) async {
    switch (envelope.action) {
      // ---- screen ---------------------------------------------------------
      case 'screen.capture':
        final b64 = await screenBridge.captureScreenshot();
        return {'screenshot': b64};
      case 'screen.stop_live':
        await screenBridge.stopLiveStream();
        return {};

      // ---- input ------------------------------------------------------------
      case 'input.tap':
        await inputBridge.tap((p['x'] as num).toDouble(), (p['y'] as num).toDouble());
        return {};
      case 'input.swipe':
        await inputBridge.swipe(
          (p['x1'] as num).toDouble(),
          (p['y1'] as num).toDouble(),
          (p['x2'] as num).toDouble(),
          (p['y2'] as num).toDouble(),
          durationMs: (p['duration_ms'] as num?)?.toInt() ?? 200,
        );
        return {};
      case 'input.type_text':
        await inputBridge.typeText(p['text'] as String? ?? '');
        return {};

      // ---- files --------------------------------------------------------------
      case 'files.list':
        final entries = await filesBridge.listDirectory(p['path'] as String? ?? '');
        return {'entries': entries};
      case 'files.read':
      case 'data.download':
        final data = await filesBridge.readFile(p['path'] as String? ?? p['target_path'] as String? ?? '');
        return {'data': data};
      case 'files.write':
      case 'data.upload':
        final ok = await filesBridge.writeFile(
          p['path'] as String? ?? p['target_path'] as String? ?? '',
          envelope.payload ?? '',
        );
        return {'success': ok};
      case 'files.delete':
        final ok = await filesBridge.deleteFile(p['path'] as String? ?? '');
        return {'success': ok};

      // ---- app_launcher ---------------------------------------------------
      case 'app_launcher.launch':
        final ok = await appLauncherBridge.launchApp(p['identifier'] as String? ?? '');
        return {'success': ok};
      case 'app_launcher.list':
        final apps = await appLauncherBridge.listInstalledApps();
        return {'apps': apps};

      // ---- browser ------------------------------------------------------------
      // Fix — pehle yeh sirf Android (semantic-tree) path tha; Windows/
      // Linux par `browserBridge.*` calls `NotImplemented` return karte
      // (native side par koi handler nahi), aur is comment mein claim
      // kiya jaata tha ke "CdpClient apne flow mein use hota hai" — jo
      // sach nahi tha, `CdpClient` kahin instantiate hi nahi hota tha.
      // Ab platform ke hisaab se branch karte hain: Android par existing
      // accessibility path, Windows/Linux par `_ensureDesktopBrowser()`
      // se CDP session.
      case 'browser.navigate':
        if (Platform.isAndroid) {
          final ok = await browserBridge.openUrl(p['url'] as String? ?? '');
          return {'success': ok};
        }
        final cdp = await _ensureDesktopBrowser();
        await cdp.navigate(p['url'] as String? ?? '');
        return {'success': true};
      case 'browser.click':
        if (Platform.isAndroid) {
          final ok = await browserBridge.findAndClick(p['text'] as String? ?? '');
          return {'success': ok};
        }
        final cdp = await _ensureDesktopBrowser();
        final ok = await cdp.clickByText(p['text'] as String? ?? '');
        return {'success': ok};
      case 'browser.type_text':
        if (Platform.isAndroid) {
          final ok = await browserBridge.findAndType(
            p['field_label'] as String? ?? '',
            p['text'] as String? ?? '',
          );
          return {'success': ok};
        }
        final cdp = await _ensureDesktopBrowser();
        final ok = await cdp.typeByLabel(
          p['field_label'] as String? ?? '',
          p['text'] as String? ?? '',
        );
        return {'success': ok};
      case 'browser.read':
        if (Platform.isAndroid) {
          final text = await browserBridge.getVisibleText();
          return {'text': text};
        }
        final cdp = await _ensureDesktopBrowser();
        final text = await cdp.getVisibleText();
        return {'text': text};

      // ---- clipboard ----------------------------------------------------------
      case 'clipboard.read':
        final text = await clipboardBridge.readText();
        return {'text': text};
      case 'clipboard.write':
        final ok = await clipboardBridge.writeText(p['text'] as String? ?? '');
        return {'success': ok};

      // ---- contacts -----------------------------------------------------------
      case 'contacts.list':
        final contacts = await contactsBridge.listContacts();
        return {
          'contacts': contacts
              .map((c) => {
                    'id': c.id,
                    'name': c.name,
                    'phoneNumbers': c.phoneNumbers,
                    'emails': c.emails,
                  })
              .toList(),
        };

      // ---- location -----------------------------------------------------------
      case 'location.refresh':
        final loc = await locationNetworkBridge.getLocation();
        return {'location': loc};

      // ---- control --------------------------------------------------------
      case 'control.switch':
        // Task lifecycle se related nahi — session-level meta-event,
        // server hi (/sessions/{id}/switch) is se deal karta hai. Device
        // tak yeh route hi nahi hota is dispatcher se; agar kabhi ho bhi
        // to yahan sirf acknowledge.
        return {'acknowledged': true};

      // ---- control.pause/resume/stop — P0-01: real local state ------------
      // Server ne yeh command sirf tabhi forward ki hai jab uski apni
      // TaskRecord state machine ne transition ko valid maana ho — is
      // liye yahan hum blindly apply kar sakte hain (server ne pehle hi
      // fail-closed check kar liya). Device-side yeh state agle actions
      // ke liye `checkTaskGate()` ka source hai.
      case 'control.pause': {
        final sessionId = p['session_id'] as String?;
        if (sessionId == null) {
          throw ArgumentError('control.pause ke liye params.session_id required hai');
        }
        _taskFor(sessionId).status = _TaskLocalStatus.paused;
        return {'acknowledged': true, 'state': 'PAUSED'};
      }

      case 'control.resume': {
        final sessionId = p['session_id'] as String?;
        if (sessionId == null) {
          throw ArgumentError('control.resume ke liye params.session_id required hai');
        }
        final task = _taskFor(sessionId);
        task.status = _TaskLocalStatus.running;

        // Audit fix (Section 8) — agar server ne apna authoritative
        // checkpoint bheja hai (`params.server_checkpoint`, server ke
        // `TaskRecord.lastCheckpoint` se — `control_api/lib/routes/
        // commands.dart` mein set hota hai) aur woh device ke apne
        // in-memory checkpoint se AAGE hai, to usko adopt karte hain.
        // "Aage" ki condition zaroori hai: normal same-process
        // pause/resume mein device ka local checkpoint hi sabse fresh
        // hota hai (server ka thoda purana ho sakta hai agar abhi last
        // step ka event abhi tak deliver na hua ho) — sirf device
        // process restart jaisे case mein (local completedSteps == 0
        // hote hue bhi server ke paas pehle se progress hai) yeh
        // condition trigger hoti hai aur checkpoint wapas mil jaata hai,
        // warna kabhi galti se peeche nahi jaate.
        final serverCheckpoint = p['server_checkpoint'] as Map<String, dynamic>?;
        final serverSteps = serverCheckpoint?['completed_steps'] as int?;
        if (serverSteps != null && serverSteps > task.completedSteps) {
          task.completedSteps = serverSteps;
          task.lastAction = serverCheckpoint?['last_action'] as String? ?? task.lastAction;
        }

        return {
          'acknowledged': true,
          'state': 'RUNNING',
          // Checkpoint wapas bhejte hain — caller/AI orchestration isi se
          // "kahan se continue karna hai" decide kar sakta hai (audit
          // TASK-02: "resume => valid checkpoint se continue").
          'checkpoint': task.toCheckpointJson(),
        };
      }

      case 'control.stop': {
        final sessionId = p['session_id'] as String?;
        if (sessionId == null) {
          throw ArgumentError('control.stop ke liye params.session_id required hai');
        }
        _taskFor(sessionId).status = _TaskLocalStatus.stopped;
        // Live-stream cancellation `AgentConnection._onMessage` mein
        // hoti hai (is class ko WebSocket/stream ka access nahi hai) —
        // yahan sirf task state set karte hain taaki agli koi bhi action
        // `checkTaskGate()` se turant reject ho.
        return {'acknowledged': true, 'state': 'STOPPED'};
      }

      // ---- background (Section 9) ------------------------------------------
      case 'background.keepalive':
        return {'alive': true};
      case 'notifications.read_event':
      case 'messaging.get_event':
      case 'messaging.prepare_reply':
      case 'messaging.send_reply':
        // P1-06 — Section 9 ka poora background-messaging capability
        // (Android NotificationListenerService jaisi OS-level
        // integration) is round mein nahi bani — genuinely native code
        // chahiye jo main is environment mein likh kar test nahi kar
        // sakta (koi Android device/emulator available nahi). Fake stub
        // banane se behtar hai ek structured, honest "unavailable" —
        // audit: "Generic universal WhatsApp/Instagram control claim
        // mat karo... Unsupported target => CAPABILITY_UNAVAILABLE."
        throw CapabilityUnavailableException(
          envelope.action,
          'Background messaging/notifications abhi is device par implement '
          'nahi hai — OS-level notification listener service (jaise '
          'Android NotificationListenerService) chahiye, jo abhi nahi bani.',
        );

      default:
        throw UnimplementedError('Unknown action: ${envelope.action}');
    }
  }
}
