import 'package:flutter/material.dart';
import '../protocol/api_client.dart';
import 'activity_history_screen.dart';
import 'device_status_screen.dart';
import 'key_manager_screen.dart';
import '../task_monitor/background_tasks_screen.dart';

/// Section 10.1 ka "My Phone" card + navigation shortcuts — [ View Status ]
/// [ Background Tasks ] [ Activity History ] — plus Key Manager, jo poore
/// dashboard/ module ko ek jagah wire karta hai.
class HomeDashboard extends StatelessWidget {
  final DeviceAgentApiClient api;
  final String deviceId;

  const HomeDashboard({super.key, required this.api, required this.deviceId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Universal Device Agent')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _tile(
            context,
            icon: Icons.devices_other,
            title: 'Device Status',
            subtitle: 'Power / Lock / Screen / Location / Network',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) =>
                    DeviceStatusScreen(api: api, deviceId: deviceId),
              ),
            ),
          ),
          _tile(
            context,
            icon: Icons.bolt,
            title: 'Background Tasks',
            subtitle: 'Locked-device agent, notifications, messaging',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) =>
                    BackgroundTasksScreen(api: api, deviceId: deviceId),
              ),
            ),
          ),
          _tile(
            context,
            icon: Icons.history,
            title: 'Activity History',
            subtitle: 'Unified log of everything the agent has done',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) =>
                    ActivityHistoryScreen(api: api, deviceId: deviceId),
              ),
            ),
          ),
          _tile(
            context,
            icon: Icons.vpn_key,
            title: 'API Keys',
            subtitle: 'Create/revoke scoped keys (Master Key Generator)',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => KeyManagerScreen(api: api)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _tile(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Card(
      child: ListTile(
        leading: Icon(icon),
        title: Text(title),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_right),
        onTap: onTap,
      ),
    );
  }
}
