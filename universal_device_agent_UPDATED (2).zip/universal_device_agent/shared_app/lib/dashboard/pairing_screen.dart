import 'package:flutter/material.dart';
import '../platform_channels/platform_channel_bridge.dart';

/// Device identity + QR pairing UI. Actual QR generation/scan aur device
/// identity native `PairingManager` (Kotlin/C++) se aata hai
/// (Section 6.7) — yeh screen sirf `ChannelNames.pairing` ke zariye us
/// native flow ko trigger/display karti hai.
class PairingScreen extends StatefulWidget {
  final void Function(String pairingCode) onPaired;
  const PairingScreen({super.key, required this.onPaired});

  @override
  State<PairingScreen> createState() => _PairingScreenState();
}

class _PairingScreenState extends State<PairingScreen> {
  final _pairingChannel = NativeCapabilityChannel(ChannelNames.pairing);
  String? _pairingCode;
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _startPairing();
  }

  Future<void> _startPairing() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final code = await _pairingChannel.invoke<String>('generatePairingCode');
      setState(() {
        _pairingCode = code;
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = 'Pairing shuru nahi ho saki: $e';
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Pair This Device')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: _loading
              ? const CircularProgressIndicator()
              : _error != null
                  ? Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(_error!, textAlign: TextAlign.center),
                        const SizedBox(height: 16),
                        FilledButton(
                            onPressed: _startPairing,
                            child: const Text('Retry')),
                      ],
                    )
                  : Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.qr_code_2, size: 160),
                        const SizedBox(height: 16),
                        Text('Pairing code: ${_pairingCode ?? '—'}',
                            style: Theme.of(context).textTheme.titleMedium),
                        const SizedBox(height: 24),
                        FilledButton(
                          onPressed: () {
                            if (_pairingCode != null) widget.onPaired(_pairingCode!);
                          },
                          child: const Text("I've scanned it — Continue"),
                        ),
                      ],
                    ),
        ),
      ),
    );
  }
}
